const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Booking = require('../models/Booking');
const Provider = require('../models/Provider');
const Service = require('../models/Service');

// @desc    Get all bookings
// @route   GET /api/bookings
// @access  Private/Admin
exports.getBookings = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single booking
// @route   GET /api/bookings/:id
// @access  Private
exports.getBooking = asyncHandler(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id)
    .populate({
      path: 'provider',
      select: 'businessName user',
      populate: {
        path: 'user',
        select: 'name email'
      }
    })
    .populate({
      path: 'user',
      select: 'name email'
    })
    .populate('service');

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is booking owner or provider or admin
  if (
    booking.user._id.toString() !== req.user.id && 
    booking.provider.user._id.toString() !== req.user.id && 
    req.user.role !== 'admin'
  ) {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to view this booking`, 401));
  }

  res.status(200).json({
    success: true,
    data: booking
  });
});

// @desc    Create new booking
// @route   POST /api/bookings
// @access  Private
exports.createBooking = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id;

  // Check if provider exists
  const provider = await Provider.findById(req.body.provider);
  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.body.provider}`, 404));
  }

  // Check if service exists
  const service = await Service.findById(req.body.service);
  if (!service) {
    return next(new ErrorResponse(`Service not found with id of ${req.body.service}`, 404));
  }

  // Create booking
  const booking = await Booking.create(req.body);

  res.status(201).json({
    success: true,
    data: booking
  });
});

// @desc    Update booking
// @route   PUT /api/bookings/:id
// @access  Private
exports.updateBooking = asyncHandler(async (req, res, next) => {
  let booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is booking owner or admin
  if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this booking`, 401));
  }

  // Don't allow status changes through this route
  if (req.body.status) {
    delete req.body.status;
  }

  booking = await Booking.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: booking
  });
});

// @desc    Delete booking
// @route   DELETE /api/bookings/:id
// @access  Private
exports.deleteBooking = asyncHandler(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is booking owner or admin
  if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete this booking`, 401));
  }

  await booking.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get user bookings
// @route   GET /api/bookings/user
// @access  Private
exports.getUserBookings = asyncHandler(async (req, res, next) => {
  const bookings = await Booking.find({ user: req.user.id })
    .populate({
      path: 'provider',
      select: 'businessName'
    })
    .populate('service');

  res.status(200).json({
    success: true,
    count: bookings.length,
    data: bookings
  });
});

// @desc    Get provider bookings
// @route   GET /api/bookings/provider
// @access  Private/Provider
exports.getProviderBookings = asyncHandler(async (req, res, next) => {
  // Get provider id for the current user
  const provider = await Provider.findOne({ user: req.user.id });

  if (!provider) {
    return next(new ErrorResponse(`No provider found for user ${req.user.id}`, 404));
  }

  const bookings = await Booking.find({ provider: provider._id })
    .populate({
      path: 'user',
      select: 'name email'
    })
    .populate('service');

  res.status(200).json({
    success: true,
    count: bookings.length,
    data: bookings
  });
});

// @desc    Confirm booking
// @route   PUT /api/bookings/:id/confirm
// @access  Private/Provider
exports.confirmBooking = asyncHandler(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Get provider id for the current user
  const provider = await Provider.findOne({ user: req.user.id });

  if (!provider) {
    return next(new ErrorResponse(`No provider found for user ${req.user.id}`, 404));
  }

  // Make sure user is the provider for this booking
  if (booking.provider.toString() !== provider._id.toString()) {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to confirm this booking`, 401));
  }

  booking.status = 'confirmed';
  await booking.save();

  res.status(200).json({
    success: true,
    data: booking
  });
});

// @desc    Complete booking
// @route   PUT /api/bookings/:id/complete
// @access  Private/Provider
exports.completeBooking = asyncHandler(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Get provider id for the current user
  const provider = await Provider.findOne({ user: req.user.id });

  if (!provider) {
    return next(new ErrorResponse(`No provider found for user ${req.user.id}`, 404));
  }

  // Make sure user is the provider for this booking
  if (booking.provider.toString() !== provider._id.toString()) {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to complete this booking`, 401));
  }

  booking.status = 'completed';
  await booking.save();

  res.status(200).json({
    success: true,
    data: booking
  });
});

// @desc    Cancel booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private
exports.cancelBooking = asyncHandler(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorResponse(`Booking not found with id of ${req.params.id}`, 404));
  }

  // Get provider id if user is a provider
  let provider = null;
  if (req.user.role === 'provider') {
    provider = await Provider.findOne({ user: req.user.id });
  }

  // Make sure user is booking owner or the provider or admin
  if (
    booking.user.toString() !== req.user.id && 
    (!provider || booking.provider.toString() !== provider._id.toString()) && 
    req.user.role !== 'admin'
  ) {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to cancel this booking`, 401));
  }

  booking.status = 'cancelled';
  booking.cancellationReason = req.body.reason || 'No reason provided';
  
  // Set who cancelled
  if (booking.user.toString() === req.user.id) {
    booking.cancelledBy = 'user';
  } else if (provider && booking.provider.toString() === provider._id.toString()) {
    booking.cancelledBy = 'provider';
  } else {
    booking.cancelledBy = 'admin';
  }
  
  booking.cancelledAt = Date.now();
  
  await booking.save();

  res.status(200).json({
    success: true,
    data: booking
  });
});
