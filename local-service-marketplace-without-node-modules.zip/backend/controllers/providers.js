const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Provider = require('../models/Provider');
const User = require('../models/User');
const path = require('path');

// @desc    Get all providers
// @route   GET /api/providers
// @access  Public
exports.getProviders = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single provider
// @route   GET /api/providers/:id
// @access  Public
exports.getProvider = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.id)
    .populate('services')
    .populate({
      path: 'reviews',
      select: 'rating title comment user createdAt'
    });

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: provider
  });
});

// @desc    Create new provider
// @route   POST /api/providers
// @access  Private
exports.createProvider = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id;

  // Check if provider already exists for this user
  const existingProvider = await Provider.findOne({ user: req.user.id });

  if (existingProvider) {
    return next(new ErrorResponse(`User ${req.user.id} already has a provider profile`, 400));
  }

  // Update user role to provider
  await User.findByIdAndUpdate(req.user.id, { role: 'provider' });

  const provider = await Provider.create(req.body);

  res.status(201).json({
    success: true,
    data: provider
  });
});

// @desc    Update provider
// @route   PUT /api/providers/:id
// @access  Private
exports.updateProvider = asyncHandler(async (req, res, next) => {
  let provider = await Provider.findById(req.params.id);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is provider owner or admin
  if (provider.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this provider`, 401));
  }

  provider = await Provider.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: provider
  });
});

// @desc    Delete provider
// @route   DELETE /api/providers/:id
// @access  Private
exports.deleteProvider = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.id);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is provider owner or admin
  if (provider.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete this provider`, 401));
  }

  await provider.remove();

  // Update user role back to user if not admin
  if (req.user.role !== 'admin') {
    await User.findByIdAndUpdate(req.user.id, { role: 'user' });
  }

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get providers by service
// @route   GET /api/providers/service/:serviceId
// @access  Public
exports.getProvidersByService = asyncHandler(async (req, res, next) => {
  const providers = await Provider.find({ services: req.params.serviceId })
    .populate('user', 'name avatar')
    .populate('services');

  res.status(200).json({
    success: true,
    count: providers.length,
    data: providers
  });
});

// @desc    Get providers by location
// @route   GET /api/providers/location/:zipcode/:distance
// @access  Public
exports.getProvidersByLocation = asyncHandler(async (req, res, next) => {
  // In a real application, we would convert zipcode to lat/lng and find providers within distance
  // For now, we'll just return all providers
  const providers = await Provider.find()
    .populate('user', 'name avatar')
    .populate('services');

  res.status(200).json({
    success: true,
    count: providers.length,
    data: providers
  });
});

// @desc    Get top rated providers
// @route   GET /api/providers/top-rated
// @access  Public
exports.getTopRatedProviders = asyncHandler(async (req, res, next) => {
  const providers = await Provider.find({ averageRating: { $gte: 4 } })
    .sort('-averageRating')
    .limit(5)
    .populate('user', 'name avatar')
    .populate('services');

  res.status(200).json({
    success: true,
    count: providers.length,
    data: providers
  });
});

// @desc    Upload provider photo
// @route   PUT /api/providers/:id/photo
// @access  Private
exports.uploadProviderPhoto = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.id);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is provider owner
  if (provider.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this provider`, 401));
  }

  if (!req.files) {
    return next(new ErrorResponse(`Please upload a file`, 400));
  }

  const file = req.files.file;

  // Make sure the image is a photo
  if (!file.mimetype.startsWith('image')) {
    return next(new ErrorResponse(`Please upload an image file`, 400));
  }

  // Check filesize
  if (file.size > process.env.MAX_FILE_UPLOAD) {
    return next(
      new ErrorResponse(
        `Please upload an image less than ${process.env.MAX_FILE_UPLOAD}`,
        400
      )
    );
  }

  // Create custom filename
  file.name = `photo_${provider._id}${path.parse(file.name).ext}`;

  // Upload file
  file.mv(`${process.env.FILE_UPLOAD_PATH}/providers/${file.name}`, async err => {
    if (err) {
      console.error(err);
      return next(new ErrorResponse(`Problem with file upload`, 500));
    }

    await Provider.findByIdAndUpdate(req.params.id, { photo: file.name });

    res.status(200).json({
      success: true,
      data: file.name
    });
  });
});

// @desc    Upload provider documents
// @route   PUT /api/providers/:id/documents
// @access  Private
exports.uploadProviderDocuments = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.id);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is provider owner
  if (provider.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this provider`, 401));
  }

  if (!req.files) {
    return next(new ErrorResponse(`Please upload a file`, 400));
  }

  // Handle multiple document uploads
  let documents = [];
  
  // Convert single file to array
  const files = Array.isArray(req.files.files) ? req.files.files : [req.files.files];

  // Check file types and sizes
  for (const file of files) {
    // Check filesize
    if (file.size > process.env.MAX_FILE_UPLOAD) {
      return next(
        new ErrorResponse(
          `Please upload files less than ${process.env.MAX_FILE_UPLOAD}`,
          400
        )
      );
    }

    // Create custom filename
    file.name = `doc_${provider._id}_${Date.now()}${path.parse(file.name).ext}`;
    documents.push(file.name);

    // Upload file
    file.mv(`${process.env.FILE_UPLOAD_PATH}/documents/${file.name}`, err => {
      if (err) {
        console.error(err);
        return next(new ErrorResponse(`Problem with file upload`, 500));
      }
    });
  }

  // Update provider with new document names
  await Provider.findByIdAndUpdate(
    req.params.id, 
    { 
      $push: { documents: { $each: documents } },
      verificationStatus: 'pending'
    }
  );

  res.status(200).json({
    success: true,
    data: documents
  });
});

// @desc    Verify provider
// @route   PUT /api/providers/:id/verify
// @access  Private/Admin
exports.verifyProvider = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.id);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.id}`, 404));
  }

  await Provider.findByIdAndUpdate(req.params.id, {
    verificationStatus: 'verified',
    verifiedAt: Date.now(),
    verificationNotes: req.body.notes || 'Verified by admin'
  });

  res.status(200).json({
    success: true,
    data: { message: 'Provider verified successfully' }
  });
});
