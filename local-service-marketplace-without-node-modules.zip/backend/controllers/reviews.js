const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Review = require('../models/Review');
const Provider = require('../models/Provider');
const Booking = require('../models/Booking');

// @desc    Get all reviews
// @route   GET /api/reviews
// @access  Public
exports.getReviews = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single review
// @route   GET /api/reviews/:id
// @access  Public
exports.getReview = asyncHandler(async (req, res, next) => {
  const review = await Review.findById(req.params.id)
    .populate({
      path: 'user',
      select: 'name avatar'
    })
    .populate({
      path: 'provider',
      select: 'businessName'
    });

  if (!review) {
    return next(new ErrorResponse(`Review not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: review
  });
});

// @desc    Create new review
// @route   POST /api/reviews
// @access  Private
exports.createReview = asyncHandler(async (req, res, next) => {
  // Add user to req.body
  req.body.user = req.user.id;

  // Check if provider exists
  const provider = await Provider.findById(req.body.provider);
  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.body.provider}`, 404));
  }

  // Check if user has a completed booking with this provider
  if (req.body.booking) {
    const booking = await Booking.findById(req.body.booking);
    if (!booking) {
      return next(new ErrorResponse(`Booking not found with id of ${req.body.booking}`, 404));
    }
    
    if (booking.user.toString() !== req.user.id) {
      return next(new ErrorResponse(`This booking does not belong to the user`, 401));
    }
    
    if (booking.status !== 'completed') {
      return next(new ErrorResponse(`Cannot review a booking that is not completed`, 400));
    }
  } else {
    // If no booking ID provided, check if user has any completed bookings with this provider
    const bookings = await Booking.find({
      user: req.user.id,
      provider: req.body.provider,
      status: 'completed'
    });
    
    if (bookings.length === 0) {
      return next(new ErrorResponse(`You must have a completed booking with this provider to leave a review`, 400));
    }
  }

  // Check if user already reviewed this provider
  const existingReview = await Review.findOne({
    user: req.user.id,
    provider: req.body.provider
  });

  if (existingReview) {
    return next(new ErrorResponse(`User has already reviewed this provider`, 400));
  }

  const review = await Review.create(req.body);

  res.status(201).json({
    success: true,
    data: review
  });
});

// @desc    Update review
// @route   PUT /api/reviews/:id
// @access  Private
exports.updateReview = asyncHandler(async (req, res, next) => {
  let review = await Review.findById(req.params.id);

  if (!review) {
    return next(new ErrorResponse(`Review not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is review owner
  if (review.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this review`, 401));
  }

  // Don't allow changing provider or user
  delete req.body.provider;
  delete req.body.user;

  review = await Review.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: review
  });
});

// @desc    Delete review
// @route   DELETE /api/reviews/:id
// @access  Private
exports.deleteReview = asyncHandler(async (req, res, next) => {
  const review = await Review.findById(req.params.id);

  if (!review) {
    return next(new ErrorResponse(`Review not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is review owner or admin
  if (review.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete this review`, 401));
  }

  await review.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get provider reviews
// @route   GET /api/reviews/provider/:providerId
// @access  Public
exports.getProviderReviews = asyncHandler(async (req, res, next) => {
  const provider = await Provider.findById(req.params.providerId);

  if (!provider) {
    return next(new ErrorResponse(`Provider not found with id of ${req.params.providerId}`, 404));
  }

  const reviews = await Review.find({ provider: req.params.providerId })
    .populate({
      path: 'user',
      select: 'name avatar'
    })
    .sort('-createdAt');

  res.status(200).json({
    success: true,
    count: reviews.length,
    data: reviews
  });
});
