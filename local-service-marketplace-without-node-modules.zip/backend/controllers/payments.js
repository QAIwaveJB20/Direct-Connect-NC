const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const Payment = require('../models/Payment');
const Booking = require('../models/Booking');
const Provider = require('../models/Provider');
const User = require('../models/User');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// @desc    Create payment intent
// @route   POST /api/payments/create-payment-intent
// @access  Private
exports.createPaymentIntent = asyncHandler(async (req, res, next) => {
  const { bookingId, paymentType } = req.body;

  let amount;
  let metadata = {};

  if (paymentType === 'booking') {
    // Validate booking
    const booking = await Booking.findById(bookingId);
    
    if (!booking) {
      return next(new ErrorResponse(`Booking not found with id of ${bookingId}`, 404));
    }
    
    // Make sure user is booking owner
    if (booking.user.toString() !== req.user.id) {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to pay for this booking`, 401));
    }
    
    // Check if booking is already paid
    if (booking.paymentStatus === 'paid') {
      return next(new ErrorResponse(`Booking ${bookingId} is already paid`, 400));
    }
    
    amount = booking.price * 100; // Convert to cents for Stripe
    metadata = {
      bookingId,
      userId: req.user.id,
      providerId: booking.provider.toString(),
      paymentType
    };
  } else if (paymentType === 'subscription') {
    // Get provider for current user
    const provider = await Provider.findOne({ user: req.user.id });
    
    if (!provider) {
      return next(new ErrorResponse(`No provider profile found for user ${req.user.id}`, 404));
    }
    
    // Set subscription amount (could be dynamic based on subscription tier)
    amount = 2999; // $29.99 per month
    metadata = {
      userId: req.user.id,
      providerId: provider._id.toString(),
      paymentType
    };
  } else if (paymentType === 'verification') {
    // Get provider for current user
    const provider = await Provider.findOne({ user: req.user.id });
    
    if (!provider) {
      return next(new ErrorResponse(`No provider profile found for user ${req.user.id}`, 404));
    }
    
    // Set verification fee
    amount = 1999; // $19.99 one-time fee
    metadata = {
      userId: req.user.id,
      providerId: provider._id.toString(),
      paymentType
    };
  } else {
    return next(new ErrorResponse(`Invalid payment type: ${paymentType}`, 400));
  }

  // Create payment intent
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: 'usd',
    metadata
  });

  res.status(200).json({
    success: true,
    clientSecret: paymentIntent.client_secret
  });
});

// @desc    Confirm payment
// @route   POST /api/payments/confirm/:paymentIntentId
// @access  Private
exports.confirmPayment = asyncHandler(async (req, res, next) => {
  const { paymentIntentId } = req.params;

  // Retrieve payment intent from Stripe
  const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

  if (!paymentIntent) {
    return next(new ErrorResponse(`Payment intent not found with id of ${paymentIntentId}`, 404));
  }

  // Check if payment is successful
  if (paymentIntent.status !== 'succeeded') {
    return next(new ErrorResponse(`Payment has not been completed successfully`, 400));
  }

  const { bookingId, userId, providerId, paymentType } = paymentIntent.metadata;

  // Make sure user is the one who made the payment
  if (userId !== req.user.id) {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to confirm this payment`, 401));
  }

  // Create payment record
  const payment = await Payment.create({
    user: userId,
    provider: providerId,
    booking: paymentType === 'booking' ? bookingId : null,
    amount: paymentIntent.amount / 100, // Convert from cents
    currency: paymentIntent.currency,
    paymentMethod: paymentIntent.payment_method_types[0],
    paymentIntentId,
    status: 'succeeded',
    paymentType,
    receiptUrl: null // Would be set from Stripe webhook in production
  });

  // Update related records based on payment type
  if (paymentType === 'booking') {
    await Booking.findByIdAndUpdate(bookingId, {
      paymentStatus: 'paid',
      paymentId: payment._id,
      paymentMethod: paymentIntent.payment_method_types[0]
    });
  } else if (paymentType === 'subscription') {
    // In a real app, this would be handled by Stripe webhook
    const oneMonthFromNow = new Date();
    oneMonthFromNow.setMonth(oneMonthFromNow.getMonth() + 1);
    
    await Provider.findByIdAndUpdate(providerId, {
      isPremium: true,
      subscriptionStatus: 'active',
      subscriptionId: 'sub_' + paymentIntentId, // In real app, would be actual subscription ID
      subscriptionExpiresAt: oneMonthFromNow
    });
    
    // Update payment with subscription details
    await Payment.findByIdAndUpdate(payment._id, {
      subscriptionId: 'sub_' + paymentIntentId,
      subscriptionPeriodStart: new Date(),
      subscriptionPeriodEnd: oneMonthFromNow
    });
  } else if (paymentType === 'verification') {
    // Mark provider as pending verification after payment
    await Provider.findByIdAndUpdate(providerId, {
      verificationStatus: 'pending'
    });
  }

  res.status(200).json({
    success: true,
    data: payment
  });
});

// @desc    Get payment history
// @route   GET /api/payments/history
// @access  Private
exports.getPaymentHistory = asyncHandler(async (req, res, next) => {
  const payments = await Payment.find({ user: req.user.id })
    .populate({
      path: 'provider',
      select: 'businessName'
    })
    .populate({
      path: 'booking',
      select: 'date startTime service',
      populate: {
        path: 'service',
        select: 'name'
      }
    })
    .sort('-createdAt');

  res.status(200).json({
    success: true,
    count: payments.length,
    data: payments
  });
});

// @desc    Get payment details
// @route   GET /api/payments/:id
// @access  Private
exports.getPaymentDetails = asyncHandler(async (req, res, next) => {
  const payment = await Payment.findById(req.params.id)
    .populate({
      path: 'provider',
      select: 'businessName'
    })
    .populate({
      path: 'booking',
      select: 'date startTime service status',
      populate: {
        path: 'service',
        select: 'name'
      }
    });

  if (!payment) {
    return next(new ErrorResponse(`Payment not found with id of ${req.params.id}`, 404));
  }

  // Make sure user is payment owner or admin
  if (payment.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse(`User ${req.user.id} is not authorized to view this payment`, 401));
  }

  res.status(200).json({
    success: true,
    data: payment
  });
});

// @desc    Create subscription
// @route   POST /api/payments/subscription/create
// @access  Private/Provider
exports.createSubscription = asyncHandler(async (req, res, next) => {
  const { paymentMethodId } = req.body;

  // Get provider for current user
  const provider = await Provider.findOne({ user: req.user.id });
  
  if (!provider) {
    return next(new ErrorResponse(`No provider profile found for user ${req.user.id}`, 404));
  }

  // In a real application, this would create a Stripe Customer and Subscription
  // For this demo, we'll create a payment intent for a one-time payment
  
  // Create payment intent for subscription
  const paymentIntent = await stripe.paymentIntents.create({
    amount: 2999, // $29.99
    currency: 'usd',
    payment_method: paymentMethodId,
    confirm: true,
    metadata: {
      userId: req.user.id,
      providerId: provider._id.toString(),
      paymentType: 'subscription'
    }
  });

  // Create payment record
  const payment = await Payment.create({
    user: req.user.id,
    provider: provider._id,
    amount: 29.99,
    currency: 'usd',
    paymentMethod: 'card',
    paymentIntentId: paymentIntent.id,
    status: 'succeeded',
    paymentType: 'subscription',
    subscriptionId: 'sub_' + paymentIntent.id, // In real app, would be actual subscription ID
    subscriptionPeriodStart: new Date(),
    subscriptionPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
  });

  // Update provider with subscription details
  await Provider.findByIdAndUpdate(provider._id, {
    isPremium: true,
    subscriptionStatus: 'active',
    subscriptionId: 'sub_' + paymentIntent.id,
    subscriptionExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  });

  res.status(200).json({
    success: true,
    data: payment
  });
});

// @desc    Cancel subscription
// @route   POST /api/payments/subscription/cancel
// @access  Private/Provider
exports.cancelSubscription = asyncHandler(async (req, res, next) => {
  // Get provider for current user
  const provider = await Provider.findOne({ user: req.user.id });
  
  if (!provider) {
    return next(new ErrorResponse(`No provider profile found for user ${req.user.id}`, 404));
  }

  if (!provider.subscriptionId) {
    return next(new ErrorResponse(`No active subscription found for this provider`, 400));
  }

  // In a real application, this would cancel the Stripe Subscription
  // For this demo, we'll just update the provider record
  
  await Provider.findByIdAndUpdate(provider._id, {
    subscriptionStatus: 'canceled',
    // Keep isPremium true until subscription expires
  });

  res.status(200).json({
    success: true,
    data: { message: 'Subscription canceled successfully' }
  });
});

// @desc    Handle Stripe webhook
// @route   POST /api/payments/webhook
// @access  Public
exports.handleStripeWebhook = asyncHandler(async (req, res, next) => {
  const signature = req.headers['stripe-signature'];

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the event
  switch (event.type) {
    case 'payment_intent.succeeded':
      const paymentIntent = event.data.object;
      // Update payment status
      if (paymentIntent.metadata.paymentType === 'booking') {
        await Booking.findByIdAndUpdate(paymentIntent.metadata.bookingId, {
          paymentStatus: 'paid'
        });
      }
      break;
    case 'invoice.payment_succeeded':
      // Handle subscription payment
      const invoice = event.data.object;
      // Update subscription status
      break;
    case 'invoice.payment_failed':
      // Handle failed subscription payment
      const failedInvoice = event.data.object;
      // Update subscription status
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.status(200).json({ received: true });
});
