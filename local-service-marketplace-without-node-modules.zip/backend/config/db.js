const mongoose = require('mongoose');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

// Load environment variables
dotenv.config();

// Connect to MongoDB
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log(`MongoDB Connected: ${conn.connection.host}`);
    
    // Seed data if DB is empty
    await seedData();
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

// Seed database with initial data
const seedData = async () => {
  try {
    // Check if we already have users in the database
    const User = require('./models/User');
    const userCount = await User.countDocuments();
    
    if (userCount > 0) {
      console.log('Database already seeded');
      return;
    }
    
    console.log('Seeding database with initial data...');
    
    // Load models
    const Provider = require('./models/Provider');
    const Service = require('./models/Service');
    const Category = require('./models/Category');
    
    // Create categories
    const categories = [
      { name: 'Home Services', slug: 'home-services', description: 'Services for your home' },
      { name: 'Personal Care', slug: 'personal-care', description: 'Beauty and wellness services' },
      { name: 'Professional Services', slug: 'professional', description: 'Business and professional services' },
      { name: 'Events & Entertainment', slug: 'events', description: 'Services for events and entertainment' },
      { name: 'Tech Services', slug: 'tech', description: 'Technology related services' },
      { name: 'Education & Tutoring', slug: 'education', description: 'Educational services and tutoring' }
    ];
    
    const createdCategories = await Category.insertMany(categories);
    console.log(`${createdCategories.length} categories created`);
    
    // Create admin user
    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@example.com',
      password: 'password123',
      role: 'admin',
      phone: '555-123-4567',
      address: {
        street: '123 Admin St',
        city: 'Charlotte',
        state: 'NC',
        zipCode: '28269',
        country: 'USA'
      }
    });
    
    console.log('Admin user created');
    
    // Create provider user
    const providerUser = await User.create({
      name: 'John Provider',
      email: 'provider@example.com',
      password: 'password123',
      role: 'provider',
      phone: '555-987-6543',
      address: {
        street: '456 Provider Ave',
        city: 'Cornelius',
        state: 'NC',
        zipCode: '28031',
        country: 'USA'
      }
    });
    
    console.log('Provider user created');
    
    // Create regular user
    const regularUser = await User.create({
      name: 'Jane Customer',
      email: 'customer@example.com',
      password: 'password123',
      role: 'user',
      phone: '555-456-7890',
      address: {
        street: '789 Customer Blvd',
        city: 'Charlotte',
        state: 'NC',
        zipCode: '28269',
        country: 'USA'
      }
    });
    
    console.log('Regular user created');
    
    // Create provider profile
    const provider = await Provider.create({
      user: providerUser._id,
      businessName: 'John\'s Home Services',
      description: 'Professional home services with over 10 years of experience. Specializing in plumbing, electrical work, and general home repairs.',
      email: 'contact@johnshomeservices.com',
      phone: '555-987-6543',
      website: 'https://johnshomeservices.com',
      address: {
        street: '456 Provider Ave',
        city: 'Cornelius',
        state: 'NC',
        zipCode: '28031',
        country: 'USA'
      },
      categories: [createdCategories[0]._id], // Home Services
      verificationStatus: 'verified',
      isPremium: true,
      averageRating: 4.8,
      totalReviews: 24,
      availability: {
        monday: { isAvailable: true, start: '08:00', end: '18:00' },
        tuesday: { isAvailable: true, start: '08:00', end: '18:00' },
        wednesday: { isAvailable: true, start: '08:00', end: '18:00' },
        thursday: { isAvailable: true, start: '08:00', end: '18:00' },
        friday: { isAvailable: true, start: '08:00', end: '18:00' },
        saturday: { isAvailable: true, start: '09:00', end: '15:00' },
        sunday: { isAvailable: false, start: '', end: '' }
      },
      serviceArea: 25
    });
    
    console.log('Provider profile created');
    
    // Create services for the provider
    const services = [
      {
        name: 'Plumbing Repair',
        description: 'Professional plumbing repair services including fixing leaks, unclogging drains, and repairing fixtures.',
        price: 85,
        duration: 60,
        category: createdCategories[0]._id, // Home Services
        provider: provider._id
      },
      {
        name: 'Electrical Work',
        description: 'Licensed electrical services including outlet installation, lighting fixtures, and electrical panel upgrades.',
        price: 95,
        duration: 90,
        category: createdCategories[0]._id, // Home Services
        provider: provider._id
      },
      {
        name: 'Handyman Services',
        description: 'General handyman services for small repairs and home maintenance tasks.',
        price: 65,
        duration: 60,
        category: createdCategories[0]._id, // Home Services
        provider: provider._id
      }
    ];
    
    const createdServices = await Service.insertMany(services);
    console.log(`${createdServices.length} services created`);
    
    // Update provider with services
    await Provider.findByIdAndUpdate(provider._id, {
      services: createdServices.map(service => service._id)
    });
    
    console.log('Database seeded successfully');
  } catch (error) {
    console.error(`Error seeding database: ${error.message}`);
  }
};

module.exports = connectDB;
