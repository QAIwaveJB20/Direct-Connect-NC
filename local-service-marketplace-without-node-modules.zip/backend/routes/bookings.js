const express = require('express');
const router = express.Router();
const { 
  getBookings,
  getBooking,
  createBooking,
  updateBooking,
  deleteBooking,
  getUserBookings,
  getProviderBookings,
  confirmBooking,
  completeBooking,
  cancelBooking
} = require('../controllers/bookings');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.route('/')
  .get(authorize('admin'), getBookings)
  .post(createBooking);

router.route('/user')
  .get(getUserBookings);

router.route('/provider')
  .get(authorize('provider'), getProviderBookings);

router.route('/:id')
  .get(getBooking)
  .put(updateBooking)
  .delete(deleteBooking);

router.route('/:id/confirm')
  .put(authorize('provider'), confirmBooking);

router.route('/:id/complete')
  .put(authorize('provider'), completeBooking);

router.route('/:id/cancel')
  .put(cancelBooking);

module.exports = router;
