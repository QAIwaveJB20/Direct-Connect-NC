const express = require('express');
const router = express.Router();
const { 
  getReviews,
  getReview,
  createReview,
  updateReview,
  deleteReview,
  getProviderReviews
} = require('../controllers/reviews');
const { protect, authorize } = require('../middleware/auth');

router.route('/')
  .get(getReviews)
  .post(protect, createReview);

router.route('/provider/:providerId')
  .get(getProviderReviews);

router.route('/:id')
  .get(getReview)
  .put(protect, updateReview)
  .delete(protect, authorize('admin'), deleteReview);

module.exports = router;
