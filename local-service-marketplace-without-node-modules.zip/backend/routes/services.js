const express = require('express');
const router = express.Router();
const { 
  getServices,
  getService,
  createService,
  updateService,
  deleteService,
  getServicesByCategory,
  getPopularServices,
  uploadServiceImage
} = require('../controllers/services');
const { protect, authorize } = require('../middleware/auth');

router.route('/')
  .get(getServices)
  .post(protect, authorize('admin', 'provider'), createService);

router.route('/popular')
  .get(getPopularServices);

router.route('/category/:categoryId')
  .get(getServicesByCategory);

router.route('/:id')
  .get(getService)
  .put(protect, authorize('admin', 'provider'), updateService)
  .delete(protect, authorize('admin', 'provider'), deleteService);

router.route('/:id/image')
  .put(protect, authorize('admin', 'provider'), uploadServiceImage);

module.exports = router;
