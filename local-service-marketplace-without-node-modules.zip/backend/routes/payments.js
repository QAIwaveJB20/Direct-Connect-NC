const express = require('express');
const router = express.Router();
const { 
  createPaymentIntent,
  confirmPayment,
  getPaymentHistory,
  getPaymentDetails,
  createSubscription,
  cancelSubscription,
  handleStripeWebhook
} = require('../controllers/payments');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.route('/create-payment-intent')
  .post(createPaymentIntent);

router.route('/confirm/:paymentIntentId')
  .post(confirmPayment);

router.route('/history')
  .get(getPaymentHistory);

router.route('/:id')
  .get(getPaymentDetails);

router.route('/subscription/create')
  .post(authorize('provider'), createSubscription);

router.route('/subscription/cancel')
  .post(authorize('provider'), cancelSubscription);

// Stripe webhook - no auth required
router.post('/webhook', express.raw({type: 'application/json'}), handleStripeWebhook);

module.exports = router;
