const express = require('express');
const router = express.Router();
const { 
  getProviders,
  getProvider,
  createProvider,
  updateProvider,
  deleteProvider,
  getProvidersByService,
  getProvidersByLocation,
  getTopRatedProviders,
  uploadProviderPhoto,
  uploadProviderDocuments,
  verifyProvider
} = require('../controllers/providers');
const { protect, authorize } = require('../middleware/auth');

router.route('/')
  .get(getProviders)
  .post(protect, createProvider);

router.route('/top-rated')
  .get(getTopRatedProviders);

router.route('/service/:serviceId')
  .get(getProvidersByService);

router.route('/location/:zipcode/:distance')
  .get(getProvidersByLocation);

router.route('/:id')
  .get(getProvider)
  .put(protect, updateProvider)
  .delete(protect, deleteProvider);

router.route('/:id/photo')
  .put(protect, uploadProviderPhoto);

router.route('/:id/documents')
  .put(protect, uploadProviderDocuments);

router.route('/:id/verify')
  .put(protect, authorize('admin'), verifyProvider);

module.exports = router;
