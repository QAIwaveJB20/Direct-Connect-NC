const mongoose = require('mongoose');

const ServiceSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a service name'],
    trim: true,
    maxlength: [100, 'Service name cannot be more than 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Please add a description'],
    maxlength: [1000, 'Description cannot be more than 1000 characters']
  },
  category: {
    type: mongoose.Schema.ObjectId,
    ref: 'Category',
    required: [true, 'Please add a category']
  },
  image: {
    type: String,
    default: 'default-service.jpg'
  },
  priceType: {
    type: String,
    enum: ['hourly', 'fixed', 'variable'],
    default: 'hourly'
  },
  price: {
    type: Number,
    required: [true, 'Please add a price']
  },
  pricingDetails: {
    type: String,
    maxlength: [500, 'Pricing details cannot be more than 500 characters']
  },
  duration: {
    type: Number, // Duration in minutes
    default: 60
  },
  isPopular: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Service', ServiceSchema);
