const mongoose = require('mongoose');

const PaymentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  provider: {
    type: mongoose.Schema.ObjectId,
    ref: 'Provider'
  },
  booking: {
    type: mongoose.Schema.ObjectId,
    ref: 'Booking'
  },
  amount: {
    type: Number,
    required: [true, 'Please add an amount']
  },
  currency: {
    type: String,
    default: 'usd'
  },
  paymentMethod: {
    type: String,
    required: [true, 'Please add a payment method']
  },
  paymentIntentId: String,
  chargeId: String,
  status: {
    type: String,
    enum: ['pending', 'succeeded', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentType: {
    type: String,
    enum: ['booking', 'subscription', 'verification'],
    required: true
  },
  subscriptionId: String,
  subscriptionPeriodStart: Date,
  subscriptionPeriodEnd: Date,
  receiptUrl: String,
  refundReason: String,
  refundedAt: Date,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Payment', PaymentSchema);
