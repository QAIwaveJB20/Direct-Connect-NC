
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const mongoose = require('mongoose');

describe('Authentication API', () => {
  let testUser;
  
  beforeAll(async () => {
    // Clear test users
    await User.deleteMany({ email: { $regex: /^test.*/ } });
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await mongoose.disconnect();
  });

  it('should register a new user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test User',
        email: 'test@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Test St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('token');
    expect(res.body.data).toHaveProperty('name', 'Test User');
    
    testUser = res.body.data;
  });

  it('should login a user', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body.data).toHaveProperty('name', 'Test User');
  });

  it('should not login with incorrect password', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'wrongpassword'
      });
    
    expect(res.statusCode).toEqual(401);
    expect(res.body).toHaveProperty('success', false);
  });

  it('should get current user profile', async () => {
    // First login to get token
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    
    const token = loginRes.body.token;
    
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('name', 'Test User');
    expect(res.body.data).toHaveProperty('email', 'test@example.com');
  });
});
