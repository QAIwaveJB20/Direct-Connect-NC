
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const Service = require('../../backend/models/Service');
const Booking = require('../../backend/models/Booking');
const Payment = require('../../backend/models/Payment');
const mongoose = require('mongoose');

describe('Payment API', () => {
  let customerUser;
  let customerToken;
  let providerUser;
  let providerToken;
  let testProvider;
  let testService;
  let testBooking;
  
  beforeAll(async () => {
    // Create test customer
    const customerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Payment Customer',
        email: 'testpaymentcustomer@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    customerUser = customerRes.body.data;
    customerToken = customerRes.body.token;
    
    // Create test provider
    const providerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Payment Provider',
        email: 'testpaymentprovider@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    providerUser = providerRes.body.data;
    providerToken = providerRes.body.token;
    
    // Create provider profile
    const providerProfileRes = await request(app)
      .post('/api/providers')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        businessName: 'Test Payment Business',
        description: 'A test business for payment testing',
        email: 'paymentbusiness@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    testProvider = providerProfileRes.body.data;
    
    // Create service
    const serviceRes = await request(app)
      .post('/api/services')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        name: 'Test Payment Service',
        description: 'A test service for payment',
        price: 99.99,
        duration: 60,
        category: null,
        provider: testProvider._id
      });
    
    testService = serviceRes.body.data;
    
    // Create booking
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const bookingRes = await request(app)
      .post('/api/bookings')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({
        provider: testProvider._id,
        service: testService._id,
        date: tomorrow.toISOString(),
        startTime: '10:00',
        endTime: '11:00',
        duration: 60,
        price: 99.99,
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        notes: 'Test payment booking notes'
      });
    
    testBooking = bookingRes.body.data;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^testpayment.*/ } });
    await Provider.deleteMany({ user: providerUser._id });
    await Service.deleteMany({ _id: testService._id });
    await Booking.deleteMany({ _id: testBooking._id });
    await Payment.deleteMany({ booking: testBooking._id });
    await mongoose.disconnect();
  });

  it('should create a payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({
        bookingId: testBooking._id,
        paymentType: 'booking'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });

  it('should get payment history', async () => {
    const res = await request(app)
      .get('/api/payments/history')
      .set('Authorization', `Bearer ${customerToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(Array.isArray(res.body.data)).toBeTruthy();
  });

  it('should create subscription payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        paymentType: 'subscription'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });

  it('should create verification payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        paymentType: 'verification'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });
});
