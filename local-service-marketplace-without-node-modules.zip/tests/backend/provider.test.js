
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const mongoose = require('mongoose');

describe('Provider API', () => {
  let testUser;
  let testToken;
  let testProvider;
  
  beforeAll(async () => {
    // Create test provider user
    const userRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Provider',
        email: 'testprovider@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    testUser = userRes.body.data;
    testToken = userRes.body.token;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await Provider.deleteMany({ user: testUser._id });
    await mongoose.disconnect();
  });

  it('should create a provider profile', async () => {
    const res = await request(app)
      .post('/api/providers')
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        businessName: 'Test Business',
        description: 'A test business for testing',
        email: 'business@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body.data).toHaveProperty('businessName', 'Test Business');
    expect(res.body.data).toHaveProperty('user', testUser._id);
    
    testProvider = res.body.data;
  });

  it('should get provider profile', async () => {
    const res = await request(app)
      .get(`/api/providers/${testProvider._id}`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('businessName', 'Test Business');
  });

  it('should update provider profile', async () => {
    const res = await request(app)
      .put(`/api/providers/${testProvider._id}`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        businessName: 'Updated Business Name',
        description: 'An updated description'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('businessName', 'Updated Business Name');
    expect(res.body.data).toHaveProperty('description', 'An updated description');
  });

  it('should get top rated providers', async () => {
    const res = await request(app)
      .get('/api/providers/top-rated');
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
  });
});
