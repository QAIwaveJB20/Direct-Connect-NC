
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const Service = require('../../backend/models/Service');
const Booking = require('../../backend/models/Booking');
const mongoose = require('mongoose');

describe('Booking API', () => {
  let customerUser;
  let customerToken;
  let providerUser;
  let providerToken;
  let testProvider;
  let testService;
  let testBooking;
  
  beforeAll(async () => {
    // Create test customer
    const customerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Customer',
        email: 'testcustomer@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    customerUser = customerRes.body.data;
    customerToken = customerRes.body.token;
    
    // Create test provider
    const providerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Provider',
        email: 'testprovider2@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    providerUser = providerRes.body.data;
    providerToken = providerRes.body.token;
    
    // Create provider profile
    const providerProfileRes = await request(app)
      .post('/api/providers')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        businessName: 'Test Business',
        description: 'A test business for testing',
        email: 'business@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    testProvider = providerProfileRes.body.data;
    
    // Create service
    const serviceRes = await request(app)
      .post('/api/services')
      .set('Authorization', `Bearer ${providerToken}`)
      .send({
        name: 'Test Service',
        description: 'A test service',
        price: 99.99,
        duration: 60,
        category: null,
        provider: testProvider._id
      });
    
    testService = serviceRes.body.data;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await Provider.deleteMany({ user: providerUser._id });
    await Service.deleteMany({ _id: testService._id });
    await Booking.deleteMany({ service: testService._id });
    await mongoose.disconnect();
  });

  it('should create a booking', async () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const res = await request(app)
      .post('/api/bookings')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({
        provider: testProvider._id,
        service: testService._id,
        date: tomorrow.toISOString(),
        startTime: '10:00',
        endTime: '11:00',
        duration: 60,
        price: 99.99,
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        notes: 'Test booking notes'
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body.data).toHaveProperty('service', testService._id);
    expect(res.body.data).toHaveProperty('provider', testProvider._id);
    expect(res.body.data).toHaveProperty('user', customerUser._id);
    expect(res.body.data).toHaveProperty('status', 'pending');
    
    testBooking = res.body.data;
  });

  it('should get user bookings', async () => {
    const res = await request(app)
      .get('/api/bookings/user')
      .set('Authorization', `Bearer ${customerToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0]).toHaveProperty('_id', testBooking._id);
  });

  it('should get provider bookings', async () => {
    const res = await request(app)
      .get('/api/bookings/provider')
      .set('Authorization', `Bearer ${providerToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0]).toHaveProperty('_id', testBooking._id);
  });

  it('should confirm a booking', async () => {
    const res = await request(app)
      .put(`/api/bookings/${testBooking._id}/confirm`)
      .set('Authorization', `Bearer ${providerToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('status', 'confirmed');
  });

  it('should complete a booking', async () => {
    const res = await request(app)
      .put(`/api/bookings/${testBooking._id}/complete`)
      .set('Authorization', `Bearer ${providerToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('status', 'completed');
  });
});
