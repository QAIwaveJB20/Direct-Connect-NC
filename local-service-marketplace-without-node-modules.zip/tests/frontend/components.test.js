
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { AuthProvider } from '../../frontend/src/app/context/AuthContext';
import { ProviderProvider } from '../../frontend/src/app/context/ProviderContext';
import { ServiceProvider } from '../../frontend/src/app/context/ServiceContext';
import { BookingProvider } from '../../frontend/src/app/context/BookingContext';
import { PaymentProvider } from '../../frontend/src/app/context/PaymentContext';
import LoginPage from '../../frontend/src/app/login/page';
import SignupPage from '../../frontend/src/app/signup/page';
import DashboardPage from '../../frontend/src/app/dashboard/page';
import SearchPage from '../../frontend/src/app/services/search/page';

// Mock the next/navigation
jest.mock('next/navigation', () => ({
  useRouter: () => ({
    push: jest.fn(),
    back: jest.fn(),
    forward: jest.fn()
  }),
  useParams: () => ({
    id: '123'
  })
}));

// Mock the API calls
jest.mock('../../frontend/src/app/api', () => ({
  loginUser: jest.fn().mockResolvedValue({ token: 'test-token', data: { name: 'Test User', email: 'test@example.com' } }),
  registerUser: jest.fn().mockResolvedValue({ token: 'test-token', data: { name: 'New User', email: 'new@example.com' } }),
  getCurrentUser: jest.fn().mockResolvedValue({ data: { name: 'Test User', email: 'test@example.com' } }),
  getProviders: jest.fn().mockResolvedValue({ data: [] }),
  getServices: jest.fn().mockResolvedValue({ data: [] }),
  getUserBookings: jest.fn().mockResolvedValue({ data: [] }),
  getPaymentHistory: jest.fn().mockResolvedValue({ data: [] })
}));

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn()
};
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

describe('Frontend Components', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Login page renders correctly', () => {
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    expect(screen.getByText('Sign in')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign In/i })).toBeInTheDocument();
  });

  test('Signup page renders correctly', () => {
    render(
      <AuthProvider>
        <SignupPage />
      </AuthProvider>
    );
    
    expect(screen.getByText('Create an Account')).toBeInTheDocument();
    expect(screen.getByText('Account Information')).toBeInTheDocument();
    expect(screen.getByLabelText(/Full Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^Password/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Confirm Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Next/i })).toBeInTheDocument();
  });

  test('Dashboard page shows login prompt when not authenticated', () => {
    render(
      <AuthProvider>
        <BookingProvider>
          <PaymentProvider>
            <DashboardPage />
          </PaymentProvider>
        </BookingProvider>
      </AuthProvider>
    );
    
    expect(screen.getByText('Please log in to view your dashboard')).toBeInTheDocument();
  });

  test('Search page renders correctly', () => {
    render(
      <AuthProvider>
        <ProviderProvider>
          <ServiceProvider>
            <SearchPage />
          </ServiceProvider>
        </ProviderProvider>
      </AuthProvider>
    );
    
    expect(screen.getByText('Find Local Service Providers')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('What service are you looking for?')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Location (City, State, or ZIP)')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Search/i })).toBeInTheDocument();
  });
});
