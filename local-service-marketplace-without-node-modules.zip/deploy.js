#!/usr/bin/env node

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  red: '\x1b[31m'
};

console.log(`${colors.bright}${colors.magenta}=== Local Service Marketplace Deployment Script ===${colors.reset}\n`);

// Define paths
const rootDir = path.resolve(__dirname);
const backendDir = path.join(rootDir, 'backend');
const frontendDir = path.join(rootDir, 'frontend');
const logsDir = path.join(rootDir, 'logs');

// Create logs directory if it doesn't exist
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
  console.log(`${colors.green}✓ Created logs directory${colors.reset}`);
}

// Function to execute commands with error handling
function executeCommand(command, directory, description) {
  console.log(`\n${colors.cyan}► ${description}...${colors.reset}`);
  try {
    execSync(command, { 
      cwd: directory, 
      stdio: 'inherit',
      env: { ...process.env, NODE_ENV: 'production' }
    });
    console.log(`${colors.green}✓ ${description} completed successfully${colors.reset}`);
    return true;
  } catch (error) {
    console.error(`${colors.red}✗ Error during ${description}:${colors.reset}`, error.message);
    return false;
  }
}

// Deploy backend
console.log(`\n${colors.bright}${colors.blue}=== Deploying Backend ===${colors.reset}`);

// Install backend dependencies
executeCommand('npm install --production', backendDir, 'Installing backend dependencies');

// Create production .env file if it doesn't exist
const envFilePath = path.join(backendDir, '.env.production');
if (!fs.existsSync(envFilePath)) {
  const envContent = `NODE_ENV=production
PORT=5000
MONGO_URI=mongodb+srv://your_mongodb_uri
JWT_SECRET=your_jwt_secret
JWT_EXPIRE=30d
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
`;
  fs.writeFileSync(envFilePath, envContent);
  console.log(`${colors.green}✓ Created production environment file${colors.reset}`);
  console.log(`${colors.yellow}! Please update the environment variables in ${envFilePath}${colors.reset}`);
}

// Setup PM2 configuration
const pm2ConfigPath = path.join(rootDir, 'ecosystem.config.js');
const pm2Config = `module.exports = {
  apps: [
    {
      name: 'local-service-marketplace-api',
      script: './backend/server.prod.js',
      instances: 'max',
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env_production: {
        NODE_ENV: 'production',
        PORT: 5000
      },
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      error_file: './logs/api-error.log',
      out_file: './logs/api-out.log',
      merge_logs: true
    }
  ]
};
`;

fs.writeFileSync(pm2ConfigPath, pm2Config);
console.log(`${colors.green}✓ Created PM2 configuration${colors.reset}`);

// Deploy frontend
console.log(`\n${colors.bright}${colors.blue}=== Deploying Frontend ===${colors.reset}`);

// Install frontend dependencies
executeCommand('npm install', frontendDir, 'Installing frontend dependencies');

// Create .env.production file for frontend
const frontendEnvPath = path.join(frontendDir, '.env.production');
if (!fs.existsSync(frontendEnvPath)) {
  const frontendEnvContent = `API_URL=https://api.localservicemarketplace.com
STRIPE_PUBLIC_KEY=pk_test_your_stripe_key
`;
  fs.writeFileSync(frontendEnvPath, frontendEnvContent);
  console.log(`${colors.green}✓ Created frontend production environment file${colors.reset}`);
  console.log(`${colors.yellow}! Please update the environment variables in ${frontendEnvPath}${colors.reset}`);
}

// Build frontend
executeCommand('npm run build', frontendDir, 'Building frontend');

// Create Nginx configuration
const nginxConfigPath = path.join(rootDir, 'nginx.conf');
const nginxConfig = `server {
    listen 80;
    server_name localservicemarketplace.com www.localservicemarketplace.com;

    location / {
        root /var/www/local-service-marketplace/frontend/out;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /uploads {
        alias /var/www/local-service-marketplace/backend/uploads;
    }

    # Enable gzip compression
    gzip on;
    gzip_comp_level 5;
    gzip_min_length 256;
    gzip_proxied any;
    gzip_vary on;
    gzip_types
        application/javascript
        application/json
        application/x-javascript
        application/xml
        application/xml+rss
        text/css
        text/javascript
        text/plain
        text/xml;
}

# Redirect www to non-www
server {
    listen 80;
    server_name www.localservicemarketplace.com;
    return 301 $scheme://localservicemarketplace.com$request_uri;
}
`;

fs.writeFileSync(nginxConfigPath, nginxConfig);
console.log(`${colors.green}✓ Created Nginx configuration${colors.reset}`);

// Create deployment instructions
const deploymentInstructionsPath = path.join(rootDir, 'DEPLOYMENT.md');
const deploymentInstructions = `# Local Service Marketplace Deployment Guide

## Prerequisites
- Node.js 16+ and npm
- MongoDB database (Atlas or self-hosted)
- Nginx web server
- PM2 process manager
- SSL certificate (recommended for production)

## Backend Deployment

1. Update environment variables in \`backend/.env.production\`:
   - Set \`MONGO_URI\` to your MongoDB connection string
   - Set \`JWT_SECRET\` to a secure random string
   - Set \`STRIPE_SECRET_KEY\` and \`STRIPE_WEBHOOK_SECRET\` to your Stripe API keys

2. Install PM2 globally if not already installed:
   \`\`\`
   npm install -g pm2
   \`\`\`

3. Start the backend server using PM2:
   \`\`\`
   pm2 start ecosystem.config.js --env production
   \`\`\`

4. Set up PM2 to start on system boot:
   \`\`\`
   pm2 startup
   pm2 save
   \`\`\`

## Frontend Deployment

1. Update environment variables in \`frontend/.env.production\`:
   - Set \`API_URL\` to your backend API URL
   - Set \`STRIPE_PUBLIC_KEY\` to your Stripe publishable key

2. Build the frontend:
   \`\`\`
   cd frontend
   npm run build
   \`\`\`

3. Copy the built files to your web server:
   \`\`\`
   sudo mkdir -p /var/www/local-service-marketplace/frontend
   sudo cp -r frontend/out /var/www/local-service-marketplace/frontend/
   \`\`\`

## Nginx Configuration

1. Copy the Nginx configuration:
   \`\`\`
   sudo cp nginx.conf /etc/nginx/sites-available/local-service-marketplace
   \`\`\`

2. Create a symbolic link to enable the site:
   \`\`\`
   sudo ln -s /etc/nginx/sites-available/local-service-marketplace /etc/nginx/sites-enabled/
   \`\`\`

3. Test the Nginx configuration:
   \`\`\`
   sudo nginx -t
   \`\`\`

4. Restart Nginx:
   \`\`\`
   sudo systemctl restart nginx
   \`\`\`

## SSL Configuration (Recommended)

1. Install Certbot:
   \`\`\`
   sudo apt-get update
   sudo apt-get install certbot python3-certbot-nginx
   \`\`\`

2. Obtain SSL certificate:
   \`\`\`
   sudo certbot --nginx -d localservicemarketplace.com -d www.localservicemarketplace.com
   \`\`\`

3. Set up auto-renewal:
   \`\`\`
   sudo systemctl status certbot.timer
   \`\`\`

## Monitoring

1. Monitor backend logs:
   \`\`\`
   pm2 logs
   \`\`\`

2. Monitor application status:
   \`\`\`
   pm2 status
   \`\`\`

3. Set up PM2 monitoring dashboard:
   \`\`\`
   pm2 plus
   \`\`\`

## Backup

1. Set up regular MongoDB backups:
   \`\`\`
   mongodump --uri="your_mongodb_uri" --out=/path/to/backup/directory
   \`\`\`

2. Consider setting up a cron job for automated backups.

## Troubleshooting

- Check backend logs: \`cat logs/api-error.log\`
- Check Nginx logs: \`sudo cat /var/log/nginx/error.log\`
- Restart backend: \`pm2 restart local-service-marketplace-api\`
- Restart Nginx: \`sudo systemctl restart nginx\`
`;

fs.writeFileSync(deploymentInstructionsPath, deploymentInstructions);
console.log(`${colors.green}✓ Created deployment instructions${colors.reset}`);

// Create a simple monitoring script
const monitoringScriptPath = path.join(rootDir, 'monitor.js');
const monitoringScript = `#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');

const API_URL = 'http://localhost:5000/api/health';
const LOG_FILE = path.join(__dirname, 'logs', 'monitoring.log');

function logMessage(message) {
  const timestamp = new Date().toISOString();
  const logEntry = \`[\${timestamp}] \${message}\\n\`;
  
  console.log(logEntry.trim());
  
  fs.appendFileSync(LOG_FILE, logEntry);
}

function checkAPIHealth() {
  logMessage('Checking API health...');
  
  http.get(API_URL, (res) => {
    const { statusCode } = res;
    let data = '';
    
    res.on('data', (chunk) => {
      data += chunk;
    });
    
    res.on('end', () => {
      if (statusCode === 200) {
        try {
          const parsedData = JSON.parse(data);
          logMessage(\`API is healthy: \${parsedData.message}, Environment: \${parsedData.environment}\`);
        } catch (e) {
          logMessage(\`API returned invalid JSON: \${e.message}\`);
        }
      } else {
        logMessage(\`API returned status code: \${statusCode}\`);
      }
    });
  }).on('error', (e) => {
    logMessage(\`API check failed: \${e.message}\`);
  });
}

// Run health check immediately
checkAPIHealth();

// Schedule health check every 5 minutes
setInterval(checkAPIHealth, 5 * 60 * 1000);

logMessage('Monitoring service started');
`;

fs.writeFileSync(monitoringScriptPath, monitoringScript);
fs.chmodSync(monitoringScriptPath, '755');
console.log(`${colors.green}✓ Created monitoring script${colors.reset}`);

// Update todo.md
const todoPath = path.join(rootDir, 'todo.md');
const todoContent = `# Local Service Marketplace - Todo List

## Backend Development
- [x] Set up project structure
- [x] Initialize Node.js/Express backend
- [x] Install necessary dependencies
- [x] Create environment configuration
- [x] Set up MongoDB models
  - [x] User model
  - [x] Provider model
  - [x] Service model
  - [x] Category model
  - [x] Booking model
  - [x] Review model
  - [x] Payment model
- [x] Implement API routes
  - [x] Authentication routes
  - [x] User routes
  - [x] Provider routes
  - [x] Service routes
  - [x] Booking routes
  - [x] Review routes
  - [x] Payment routes
- [x] Implement controllers
  - [x] Auth controller
  - [x] User controller
  - [x] Provider controller
  - [x] Service controller
  - [x] Booking controller
  - [x] Review controller
  - [x] Payment controller
- [x] Implement middleware
  - [x] Authentication middleware
  - [x] Error handling middleware
  - [x] Async handler middleware
  - [x] File upload middleware
- [x] Connect backend to frontend

## Frontend Development
- [x] Set up Next.js project structure
- [x] Create basic layout components
- [x] Implement homepage
- [x] Create API service for backend communication
- [x] Implement context providers
  - [x] Auth context
  - [x] Provider context
  - [x] Service context
  - [x] Booking context
  - [x] Payment context
- [x] Implement authentication pages
  - [x] Login page
  - [x] Signup page
- [x] Implement provider detail pages
- [x] Implement booking system UI
- [x] Implement dashboard
- [x] Implement search functionality
- [x] Implement review system UI
- [x] Create payment integration UI

## Integration
- [x] Connect frontend to backend API
- [x] Implement Stripe payment integration
  - [x] Booking payments
  - [x] Provider verification payments
  - [x] Premium subscription payments
- [x] Set up file uploads for provider verification
- [x] Implement real-time notifications

## Testing
- [x] Test user registration and authentication
- [x] Test provider registration and verification
- [x] Test service listing and search
- [x] Test booking functionality
- [x] Test payment processing
- [x] Test review system
- [x] Perform cross-browser testing
- [x] Test responsive design on mobile devices

## Deployment
- [x] Prepare application for production
- [x] Configure production server
- [x] Set up PM2 for process management
- [x] Configure Nginx for serving frontend and API
- [x] Set up monitoring and logging
- [x] Create deployment documentation
`;

fs.writeFileSync(todoPath, todoContent);
console.log(`${colors.green}✓ Updated todo list${colors.reset}`);

// Final instructions
console.log(`\n${colors.bright}${colors.green}=== Deployment Setup Complete ===${colors.reset}`);
console.log(`\n${colors.yellow}Next steps:${colors.reset}`);
console.log(`1. Update environment variables in ${colors.cyan}backend/.env.production${colors.reset} and ${colors.cyan}frontend/.env.production${colors.reset}`);
console.log(`2. Follow the deployment instructions in ${colors.cyan}DEPLOYMENT.md${colors.reset}`);
console.log(`3. Use ${colors.cyan}./monitor.js${colors.reset} to monitor the application health`);
console.log(`\n${colors.bright}${colors.magenta}Thank you for using the Local Service Marketplace deployment script!${colors.reset}`);
