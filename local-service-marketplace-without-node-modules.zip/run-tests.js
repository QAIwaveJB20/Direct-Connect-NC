
#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

// Start backend server
console.log('Starting backend server...');
const backend = spawn('node', ['server.js'], {
  cwd: path.join(__dirname, 'backend'),
  env: { ...process.env, NODE_ENV: 'test' },
  stdio: 'inherit'
});

// Wait for backend to start
setTimeout(() => {
  console.log('Running tests...');
  
  // Run tests
  const tests = spawn('npm', ['test'], {
    cwd: path.join(__dirname, 'tests'),
    stdio: 'inherit'
  });
  
  tests.on('close', (code) => {
    console.log(`Tests completed with code ${code}`);
    
    // Shutdown backend
    backend.kill();
    process.exit(code);
  });
}, 3000);

// Handle process termination
process.on('SIGINT', () => {
  backend.kill();
  process.exit();
});
