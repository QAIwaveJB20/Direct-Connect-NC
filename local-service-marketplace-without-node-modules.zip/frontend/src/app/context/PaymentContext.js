import React, { createContext, useContext, useState } from 'react';
import { createPaymentIntent, confirmPayment, getPaymentHistory, createSubscription, cancelSubscription } from '../api';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

// Initialize Stripe
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);

// Create payment context
const PaymentContext = createContext();

export const PaymentProvider = ({ children }) => {
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Create payment intent for booking
  const createBookingPayment = async (bookingId) => {
    setLoading(true);
    setError(null);
    try {
      const response = await createPaymentIntent({
        bookingId,
        paymentType: 'booking'
      });
      return { success: true, clientSecret: response.clientSecret };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create payment');
      return { success: false, error: error.response?.data?.error || 'Failed to create payment' };
    } finally {
      setLoading(false);
    }
  };

  // Create payment intent for provider subscription
  const createProviderSubscription = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await createPaymentIntent({
        paymentType: 'subscription'
      });
      return { success: true, clientSecret: response.clientSecret };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create subscription');
      return { success: false, error: error.response?.data?.error || 'Failed to create subscription' };
    } finally {
      setLoading(false);
    }
  };

  // Create payment intent for provider verification
  const createVerificationPayment = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await createPaymentIntent({
        paymentType: 'verification'
      });
      return { success: true, clientSecret: response.clientSecret };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create verification payment');
      return { success: false, error: error.response?.data?.error || 'Failed to create verification payment' };
    } finally {
      setLoading(false);
    }
  };

  // Confirm payment after successful Stripe payment
  const confirmPaymentIntent = async (paymentIntentId) => {
    setLoading(true);
    setError(null);
    try {
      const response = await confirmPayment(paymentIntentId);
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to confirm payment');
      return { success: false, error: error.response?.data?.error || 'Failed to confirm payment' };
    } finally {
      setLoading(false);
    }
  };

  // Fetch payment history
  const fetchPaymentHistory = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getPaymentHistory();
      setPaymentHistory(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch payment history');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Create subscription with payment method
  const createSubscriptionWithPaymentMethod = async (paymentMethodId) => {
    setLoading(true);
    setError(null);
    try {
      const response = await createSubscription(paymentMethodId);
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create subscription');
      return { success: false, error: error.response?.data?.error || 'Failed to create subscription' };
    } finally {
      setLoading(false);
    }
  };

  // Cancel subscription
  const cancelProviderSubscription = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await cancelSubscription();
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to cancel subscription');
      return { success: false, error: error.response?.data?.error || 'Failed to cancel subscription' };
    } finally {
      setLoading(false);
    }
  };

  return (
    <PaymentContext.Provider
      value={{
        paymentHistory,
        loading,
        error,
        createBookingPayment,
        createProviderSubscription,
        createVerificationPayment,
        confirmPaymentIntent,
        fetchPaymentHistory,
        createSubscriptionWithPaymentMethod,
        cancelProviderSubscription,
        stripePromise
      }}
    >
      <Elements stripe={stripePromise}>
        {children}
      </Elements>
    </PaymentContext.Provider>
  );
};

// Custom hook to use payment context
export const usePayments = () => {
  const context = useContext(PaymentContext);
  if (!context) {
    throw new Error('usePayments must be used within a PaymentProvider');
  }
  return context;
};
