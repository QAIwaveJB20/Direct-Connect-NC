import React, { createContext, useContext, useState, useEffect } from 'react';
import { getProviders, getProvider, getTopRatedProviders, getProvidersByService, getProvidersByLocation } from '../api';

// Create provider context
const ProviderContext = createContext();

export const ProviderProvider = ({ children }) => {
  const [providers, setProviders] = useState([]);
  const [topRatedProviders, setTopRatedProviders] = useState([]);
  const [currentProvider, setCurrentProvider] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch all providers
  const fetchProviders = async (params = {}) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProviders(params);
      setProviders(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch providers');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch top rated providers
  const fetchTopRatedProviders = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getTopRatedProviders();
      setTopRatedProviders(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch top rated providers');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch single provider
  const fetchProvider = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProvider(id);
      setCurrentProvider(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch provider details');
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Fetch providers by service
  const fetchProvidersByService = async (serviceId) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProvidersByService(serviceId);
      setProviders(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch providers for this service');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch providers by location
  const fetchProvidersByLocation = async (zipcode, distance = 25) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProvidersByLocation(zipcode, distance);
      setProviders(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch providers in this location');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Clear current provider
  const clearCurrentProvider = () => {
    setCurrentProvider(null);
  };

  return (
    <ProviderContext.Provider
      value={{
        providers,
        topRatedProviders,
        currentProvider,
        loading,
        error,
        fetchProviders,
        fetchTopRatedProviders,
        fetchProvider,
        fetchProvidersByService,
        fetchProvidersByLocation,
        clearCurrentProvider
      }}
    >
      {children}
    </ProviderContext.Provider>
  );
};

// Custom hook to use provider context
export const useProviders = () => {
  const context = useContext(ProviderContext);
  if (!context) {
    throw new Error('useProviders must be used within a ProviderProvider');
  }
  return context;
};
