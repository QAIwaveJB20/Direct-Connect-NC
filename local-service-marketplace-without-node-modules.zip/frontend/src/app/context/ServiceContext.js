import React, { createContext, useContext, useState, useEffect } from 'react';
import { getServices, getService, getPopularServices, getServicesByCategory } from '../api';

// Create service context
const ServiceContext = createContext();

export const ServiceProvider = ({ children }) => {
  const [services, setServices] = useState([]);
  const [popularServices, setPopularServices] = useState([]);
  const [currentService, setCurrentService] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch all services
  const fetchServices = async (params = {}) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getServices(params);
      setServices(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch services');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch popular services
  const fetchPopularServices = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getPopularServices();
      setPopularServices(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch popular services');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch single service
  const fetchService = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getService(id);
      setCurrentService(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch service details');
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Fetch services by category
  const fetchServicesByCategory = async (categoryId) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getServicesByCategory(categoryId);
      setServices(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch services for this category');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Clear current service
  const clearCurrentService = () => {
    setCurrentService(null);
  };

  return (
    <ServiceContext.Provider
      value={{
        services,
        popularServices,
        currentService,
        loading,
        error,
        fetchServices,
        fetchPopularServices,
        fetchService,
        fetchServicesByCategory,
        clearCurrentService
      }}
    >
      {children}
    </ServiceContext.Provider>
  );
};

// Custom hook to use service context
export const useServices = () => {
  const context = useContext(ServiceContext);
  if (!context) {
    throw new Error('useServices must be used within a ServiceProvider');
  }
  return context;
};
