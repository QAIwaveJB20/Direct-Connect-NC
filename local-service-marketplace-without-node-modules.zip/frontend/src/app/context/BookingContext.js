import React, { createContext, useContext, useState, useEffect } from 'react';
import { createBooking, getUserBookings, getProviderBookings, getBooking, confirmBooking, completeBooking, cancelBooking } from '../api';

// Create booking context
const BookingContext = createContext();

export const BookingProvider = ({ children }) => {
  const [userBookings, setUserBookings] = useState([]);
  const [providerBookings, setProviderBookings] = useState([]);
  const [currentBooking, setCurrentBooking] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Create a new booking
  const createNewBooking = async (bookingData) => {
    setLoading(true);
    setError(null);
    try {
      const response = await createBooking(bookingData);
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create booking');
      return { success: false, error: error.response?.data?.error || 'Failed to create booking' };
    } finally {
      setLoading(false);
    }
  };

  // Fetch user bookings
  const fetchUserBookings = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getUserBookings();
      setUserBookings(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch your bookings');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch provider bookings
  const fetchProviderBookings = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProviderBookings();
      setProviderBookings(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch provider bookings');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Fetch single booking
  const fetchBooking = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await getBooking(id);
      setCurrentBooking(response.data);
      return response.data;
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to fetch booking details');
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Confirm booking (provider only)
  const confirmBookingStatus = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await confirmBooking(id);
      
      // Update provider bookings list
      setProviderBookings(prevBookings => 
        prevBookings.map(booking => 
          booking._id === id ? { ...booking, status: 'confirmed' } : booking
        )
      );
      
      // Update current booking if it's the one being confirmed
      if (currentBooking && currentBooking._id === id) {
        setCurrentBooking({ ...currentBooking, status: 'confirmed' });
      }
      
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to confirm booking');
      return { success: false, error: error.response?.data?.error || 'Failed to confirm booking' };
    } finally {
      setLoading(false);
    }
  };

  // Complete booking (provider only)
  const completeBookingStatus = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await completeBooking(id);
      
      // Update provider bookings list
      setProviderBookings(prevBookings => 
        prevBookings.map(booking => 
          booking._id === id ? { ...booking, status: 'completed' } : booking
        )
      );
      
      // Update current booking if it's the one being completed
      if (currentBooking && currentBooking._id === id) {
        setCurrentBooking({ ...currentBooking, status: 'completed' });
      }
      
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to complete booking');
      return { success: false, error: error.response?.data?.error || 'Failed to complete booking' };
    } finally {
      setLoading(false);
    }
  };

  // Cancel booking
  const cancelBookingStatus = async (id, reason) => {
    setLoading(true);
    setError(null);
    try {
      const response = await cancelBooking(id, reason);
      
      // Update bookings lists
      const updateBookingList = (list) => 
        list.map(booking => 
          booking._id === id ? { ...booking, status: 'cancelled' } : booking
        );
      
      setUserBookings(prevBookings => updateBookingList(prevBookings));
      setProviderBookings(prevBookings => updateBookingList(prevBookings));
      
      // Update current booking if it's the one being cancelled
      if (currentBooking && currentBooking._id === id) {
        setCurrentBooking({ ...currentBooking, status: 'cancelled' });
      }
      
      return { success: true, data: response.data };
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to cancel booking');
      return { success: false, error: error.response?.data?.error || 'Failed to cancel booking' };
    } finally {
      setLoading(false);
    }
  };

  // Clear current booking
  const clearCurrentBooking = () => {
    setCurrentBooking(null);
  };

  return (
    <BookingContext.Provider
      value={{
        userBookings,
        providerBookings,
        currentBooking,
        loading,
        error,
        createNewBooking,
        fetchUserBookings,
        fetchProviderBookings,
        fetchBooking,
        confirmBookingStatus,
        completeBookingStatus,
        cancelBookingStatus,
        clearCurrentBooking
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

// Custom hook to use booking context
export const useBookings = () => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBookings must be used within a BookingProvider');
  }
  return context;
};
