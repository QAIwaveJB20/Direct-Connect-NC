import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  TextField,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Stepper,
  Step,
  StepLabel
} from '@mui/material';
import { useRouter } from 'next/navigation';
import { useAuth } from '../../context/AuthContext';
import { useProviders } from '../../context/ProviderContext';
import { usePayments } from '../../context/PaymentContext';
import StripePaymentForm from '../../components/payment/StripePaymentForm';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';

export default function VerificationPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { fetchProvider, currentProvider, loading: providerLoading } = useProviders();
  const { confirmPaymentIntent } = usePayments();
  
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [verificationFiles, setVerificationFiles] = useState({
    idDocument: null,
    businessLicense: null,
    insuranceProof: null
  });
  
  useEffect(() => {
    const loadProviderData = async () => {
      setLoading(true);
      try {
        if (user && user.id) {
          // Fetch provider details
          await fetchProvider(user.id);
        }
      } catch (err) {
        setError('Failed to load provider details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadProviderData();
  }, [user, fetchProvider]);

  const handleFileChange = (event, fileType) => {
    setVerificationFiles({
      ...verificationFiles,
      [fileType]: event.target.files[0]
    });
  };

  const handleUploadFiles = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const formData = new FormData();
      
      // Append all files to form data
      Object.entries(verificationFiles).forEach(([key, file]) => {
        if (file) {
          formData.append(key, file);
        }
      });
      
      // Upload files to backend
      const response = await fetch('/api/providers/verification/upload', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });
      
      const data = await response.json();
      
      if (response.ok) {
        // Move to next step
        setActiveStep(1);
      } else {
        setError(data.error || 'Failed to upload verification documents');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async (paymentIntent) => {
    try {
      setLoading(true);
      
      // Confirm payment on backend
      const result = await confirmPaymentIntent(paymentIntent.id);
      
      if (result.success) {
        setSuccess(true);
        setActiveStep(2);
        
        // Refresh provider data
        await fetchProvider(user.id);
      } else {
        setError(result.error || 'Failed to confirm payment');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentError = (errorMessage) => {
    setError(errorMessage);
  };

  if (loading || providerLoading) {
    return (
      <Container maxWidth="md" sx={{ py: 8, textAlign: 'center' }}>
        <CircularProgress />
        <Typography sx={{ mt: 2 }}>Loading verification details...</Typography>
      </Container>
    );
  }

  if (!user || user.role !== 'provider') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="error">Only service providers can access this page</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  if (currentProvider && currentProvider.verificationStatus === 'verified') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <CheckCircleOutlineIcon color="success" sx={{ fontSize: 64, mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            Your Account is Verified
          </Typography>
          <Typography variant="body1" paragraph>
            Your provider account has already been verified. You can now access all premium features.
          </Typography>
          <Button 
            variant="contained" 
            onClick={() => router.push('/dashboard')}
          >
            Go to Dashboard
          </Button>
        </Paper>
      </Container>
    );
  }

  if (currentProvider && currentProvider.verificationStatus === 'pending') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <Typography variant="h4" gutterBottom>
            Verification In Progress
          </Typography>
          <Typography variant="body1" paragraph>
            Your verification is currently being reviewed by our team. This process typically takes 1-2 business days.
          </Typography>
          <Typography variant="body1" paragraph>
            We'll notify you by email once your verification is complete.
          </Typography>
          <Button 
            variant="contained" 
            onClick={() => router.push('/dashboard')}
          >
            Return to Dashboard
          </Button>
        </Paper>
      </Container>
    );
  }

  const steps = ['Upload Documents', 'Payment', 'Confirmation'];

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Typography variant="h4" gutterBottom align="center">
          Provider Verification
        </Typography>
        
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        {activeStep === 0 && (
          <>
            <Typography variant="h6" gutterBottom>
              Upload Verification Documents
            </Typography>
            
            <Typography variant="body1" paragraph>
              To verify your account, please upload the following documents:
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Government-Issued ID
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      Upload a clear photo of your driver's license, passport, or other government-issued ID.
                    </Typography>
                    <Button
                      variant="contained"
                      component="label"
                      fullWidth
                    >
                      {verificationFiles.idDocument ? 'Change File' : 'Upload ID'}
                      <input
                        type="file"
                        hidden
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange(e, 'idDocument')}
                      />
                    </Button>
                    {verificationFiles.idDocument && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        Selected: {verificationFiles.idDocument.name}
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Business License (if applicable)
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      Upload your business license or registration certificate.
                    </Typography>
                    <Button
                      variant="contained"
                      component="label"
                      fullWidth
                    >
                      {verificationFiles.businessLicense ? 'Change File' : 'Upload License'}
                      <input
                        type="file"
                        hidden
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange(e, 'businessLicense')}
                      />
                    </Button>
                    {verificationFiles.businessLicense && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        Selected: {verificationFiles.businessLicense.name}
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Insurance Proof (if applicable)
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      Upload proof of liability insurance for your services.
                    </Typography>
                    <Button
                      variant="contained"
                      component="label"
                      fullWidth
                    >
                      {verificationFiles.insuranceProof ? 'Change File' : 'Upload Insurance'}
                      <input
                        type="file"
                        hidden
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange(e, 'insuranceProof')}
                      />
                    </Button>
                    {verificationFiles.insuranceProof && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        Selected: {verificationFiles.insuranceProof.name}
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
            
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                variant="contained"
                onClick={handleUploadFiles}
                disabled={!verificationFiles.idDocument || loading}
              >
                {loading ? <CircularProgress size={24} /> : 'Continue to Payment'}
              </Button>
            </Box>
          </>
        )}
        
        {activeStep === 1 && (
          <>
            <Typography variant="h6" gutterBottom>
              Verification Fee
            </Typography>
            
            <Typography variant="body1" paragraph>
              There is a one-time verification fee of $19.99 to cover the cost of processing your verification.
            </Typography>
            
            <Card variant="outlined" sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="subtitle1" gutterBottom>
                  Verification Benefits:
                </Typography>
                <ul>
                  <li>
                    <Typography variant="body2">
                      Verified badge on your profile
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2">
                      Higher ranking in search results
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2">
                      Increased trust from potential customers
                    </Typography>
                  </li>
                  <li>
                    <Typography variant="body2">
                      Access to premium features
                    </Typography>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <StripePaymentForm 
              amount={19.99}
              paymentType="verification"
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
              buttonText="Pay Verification Fee"
            />
          </>
        )}
        
        {activeStep === 2 && (
          <Box sx={{ textAlign: 'center' }}>
            <CheckCircleOutlineIcon color="success" sx={{ fontSize: 64, mb: 2 }} />
            <Typography variant="h5" gutterBottom>
              Verification Submitted Successfully
            </Typography>
            <Typography variant="body1" paragraph>
              Your verification documents have been submitted and payment has been processed.
            </Typography>
            <Typography variant="body1" paragraph>
              Our team will review your documents within 1-2 business days. You'll receive an email notification once your verification is complete.
            </Typography>
            <Button 
              variant="contained" 
              onClick={() => router.push('/dashboard')}
              sx={{ mt: 2 }}
            >
              Return to Dashboard
            </Button>
          </Box>
        )}
      </Paper>
    </Container>
  );
}
