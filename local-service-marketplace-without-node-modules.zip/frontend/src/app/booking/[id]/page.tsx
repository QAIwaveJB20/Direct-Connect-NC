import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  TextField,
  InputAdornment,
  Paper,
  Divider,
  Stepper,
  Step,
  StepLabel,
  FormControl,
  FormControlLabel,
  RadioGroup,
  Radio,
  Checkbox,
  MenuItem,
  Select,
  InputLabel,
  FormHelperText,
  Alert
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import PaymentIcon from '@mui/icons-material/Payment';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import LockIcon from '@mui/icons-material/Lock';

const BookingPage = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [selectedService, setSelectedService] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [agreeTerms, setAgreeTerms] = useState(false);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleServiceChange = (event) => {
    setSelectedService(event.target.value);
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };

  const handleTimeChange = (event) => {
    setSelectedTime(event.target.value);
  };

  const handleAddressChange = (event) => {
    setAddress(event.target.value);
  };

  const handleNotesChange = (event) => {
    setNotes(event.target.value);
  };

  const handlePaymentMethodChange = (event) => {
    setPaymentMethod(event.target.value);
  };

  const handleAgreeTermsChange = (event) => {
    setAgreeTerms(event.target.checked);
  };

  const steps = ['Select Service', 'Schedule', 'Location', 'Payment'];

  return (
    <Box>
      {/* Booking Header */}
      <Box sx={{ bgcolor: 'primary.main', color: 'white', py: 4 }}>
        <Container maxWidth="lg">
          <Typography variant="h4" component="h1" gutterBottom fontWeight="bold" textAlign="center">
            Book Elite Cleaners
          </Typography>
          <Typography variant="subtitle1" paragraph textAlign="center">
            Complete your booking in a few simple steps
          </Typography>
        </Container>
      </Box>

      {/* Booking Process */}
      <Container maxWidth="md" sx={{ py: 4 }}>
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Paper sx={{ p: 4, mb: 4 }}>
          {activeStep === 0 && (
            <Box>
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Select a Service
              </Typography>
              <Typography variant="body2" paragraph color="text.secondary">
                Choose the service you need from Elite Cleaners
              </Typography>
              
              <FormControl fullWidth sx={{ mb: 3 }}>
                <RadioGroup
                  aria-labelledby="service-selection-group"
                  name="service-selection"
                  value={selectedService}
                  onChange={handleServiceChange}
                >
                  {[
                    { 
                      id: 'regular', 
                      title: 'Regular Home Cleaning', 
                      description: 'Comprehensive cleaning of all living areas including dusting, vacuuming, mopping, and bathroom sanitizing.', 
                      price: '$120', 
                      duration: '3-4 hours',
                      popular: true
                    },
                    { 
                      id: 'deep', 
                      title: 'Deep Cleaning', 
                      description: 'Intensive cleaning service that covers hard-to-reach areas, appliances, baseboards, and more.', 
                      price: '$220', 
                      duration: '5-7 hours',
                      popular: false
                    },
                    { 
                      id: 'move', 
                      title: 'Move-In/Move-Out Cleaning', 
                      description: 'Thorough cleaning to prepare a property for new occupants or to leave it spotless when moving out.', 
                      price: '$250', 
                      duration: '6-8 hours',
                      popular: true
                    },
                    { 
                      id: 'construction', 
                      title: 'Post-Construction Cleaning', 
                      description: 'Specialized cleaning to remove dust, debris, and residues after construction or renovation work.', 
                      price: '$300', 
                      duration: '6-10 hours',
                      popular: false
                    }
                  ].map((service) => (
                    <Paper 
                      key={service.id} 
                      sx={{ 
                        mb: 2, 
                        p: 2, 
                        border: '1px solid',
                        borderColor: selectedService === service.id ? 'primary.main' : 'grey.300',
                        bgcolor: selectedService === service.id ? 'primary.50' : 'transparent',
                        position: 'relative',
                        overflow: 'hidden'
                      }}
                    >
                      {service.popular && (
                        <Box 
                          sx={{ 
                            position: 'absolute', 
                            top: 10, 
                            right: -30, 
                            transform: 'rotate(45deg)',
                            bgcolor: 'primary.main',
                            color: 'white',
                            py: 0.5,
                            px: 4
                          }}
                        >
                          <Typography variant="caption" fontWeight="bold">
                            POPULAR
                          </Typography>
                        </Box>
                      )}
                      <FormControlLabel 
                        value={service.id} 
                        control={<Radio />} 
                        label={
                          <Box sx={{ ml: 1 }}>
                            <Typography variant="subtitle1" fontWeight="bold">
                              {service.title}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {service.description}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                              <Typography variant="body2" color="text.secondary" sx={{ mr: 3 }}>
                                <AccessTimeIcon sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                                {service.duration}
                              </Typography>
                              <Typography variant="subtitle1" color="primary.main" fontWeight="bold">
                                {service.price}
                              </Typography>
                            </Box>
                          </Box>
                        }
                        sx={{ 
                          alignItems: 'flex-start', 
                          m: 0,
                          width: '100%'
                        }}
                      />
                    </Paper>
                  ))}
                </RadioGroup>
              </FormControl>
            </Box>
          )}

          {activeStep === 1 && (
            <Box>
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Schedule Your Service
              </Typography>
              <Typography variant="body2" paragraph color="text.secondary">
                Select a date and time that works for you
              </Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth sx={{ mb: 3 }}>
                    <InputLabel id="date-select-label">Select Date</InputLabel>
                    <Select
                      labelId="date-select-label"
                      id="date-select"
                      value={selectedDate}
                      label="Select Date"
                      onChange={handleDateChange}
                      startAdornment={
                        <InputAdornment position="start">
                          <CalendarMonthIcon />
                        </InputAdornment>
                      }
                    >
                      <MenuItem value="2025-04-18">Friday, April 18, 2025</MenuItem>
                      <MenuItem value="2025-04-19">Saturday, April 19, 2025</MenuItem>
                      <MenuItem value="2025-04-20">Sunday, April 20, 2025</MenuItem>
                      <MenuItem value="2025-04-21">Monday, April 21, 2025</MenuItem>
                      <MenuItem value="2025-04-22">Tuesday, April 22, 2025</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth sx={{ mb: 3 }}>
                    <InputLabel id="time-select-label">Select Time</InputLabel>
                    <Select
                      labelId="time-select-label"
                      id="time-select"
                      value={selectedTime}
                      label="Select Time"
                      onChange={handleTimeChange}
                      startAdornment={
                        <InputAdornment position="start">
                          <AccessTimeIcon />
                        </InputAdornment>
                      }
                    >
                      <MenuItem value="09:00">9:00 AM</MenuItem>
                      <MenuItem value="10:00">10:00 AM</MenuItem>
                      <MenuItem value="11:00">11:00 AM</MenuItem>
                      <MenuItem value="12:00">12:00 PM</MenuItem>
                      <MenuItem value="13:00">1:00 PM</MenuItem>
                      <MenuItem value="14:00">2:00 PM</MenuItem>
                      <MenuItem value="15:00">3:00 PM</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
              
              <Alert severity="info" sx={{ mt: 2 }}>
                Elite Cleaners typically needs 3-4 hours for a Regular Home Cleaning. Please ensure someone will be available to provide access.
              </Alert>
            </Box>
          )}

          {activeStep === 2 && (
            <Box>
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Service Location
              </Typography>
              <Typography variant="body2" paragraph color="text.secondary">
                Provide the address where the service will be performed
              </Typography>
              
              <TextField
                fullWidth
                label="Address"
                variant="outlined"
                value={address}
                onChange={handleAddressChange}
                placeholder="Enter your full address"
                sx={{ mb: 3 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LocationOnIcon />
                    </InputAdornment>
                  ),
                }}
              />
              
              <TextField
                fullWidth
                label="Special Instructions (Optional)"
                variant="outlined"
                value={notes}
                onChange={handleNotesChange}
                placeholder="Parking information, entry instructions, pets, etc."
                multiline
                rows={4}
                sx={{ mb: 3 }}
              />
            </Box>
          )}

          {activeStep === 3 && (
            <Box>
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Payment Details
              </Typography>
              <Typography variant="body2" paragraph color="text.secondary">
                Select your preferred payment method
              </Typography>
              
              <FormControl component="fieldset" sx={{ mb: 3, width: '100%' }}>
                <RadioGroup
                  aria-label="payment-method"
                  name="payment-method"
                  value={paymentMethod}
                  onChange={handlePaymentMethodChange}
                >
                  <Paper 
                    sx={{ 
                      mb: 2, 
                      p: 2, 
                      border: '1px solid',
                      borderColor: paymentMethod === 'credit_card' ? 'primary.main' : 'grey.300',
                      bgcolor: paymentMethod === 'credit_card' ? 'primary.50' : 'transparent'
                    }}
                  >
                    <FormControlLabel 
                      value="credit_card" 
                      control={<Radio />} 
                      label={
                        <Box sx={{ ml: 1 }}>
                          <Typography variant="subtitle1" fontWeight="bold">
                            Credit or Debit Card
                          </Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                            <CreditCardIcon sx={{ fontSize: 20, mr: 1 }} />
                            <Typography variant="body2" color="text.secondary">
                              Secure payment via Stripe
                            </Typography>
                          </Box>
                        </Box>
                      }
                      sx={{ alignItems: 'flex-start', m: 0 }}
                    />
                  </Paper>
                  
                  <Paper 
                    sx={{ 
                      mb: 2, 
                      p: 2, 
                      border: '1px solid',
                      borderColor: paymentMethod === 'paypal' ? 'primary.main' : 'grey.300',
                      bgcolor: paymentMethod === 'paypal' ? 'primary.50' : 'transparent'
                    }}
                  >
                    <FormControlLabel 
                      value="paypal" 
                      control={<Radio />} 
                      label={
                        <Box sx={{ ml: 1 }}>
                          <Typography variant="subtitle1" fontWeight="bold">
                            PayPal
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Pay securely using your PayPal account
                          </Typography>
                        </Box>
                      }
                      sx={{ alignItems: 'flex-start', m: 0 }}
                    />
                  </Paper>
                </RadioGroup>
              </FormControl>
              
              {paymentMethod === 'credit_card' && (
                <Box sx={{ mb: 3, p: 3, border: '1px solid', borderColor: 'grey.300', borderRadius: 1 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Card Information
                  </Typography>
                  <TextField
                    fullWidth
                    label="Card Number"
                    variant="outlined"
                    placeholder="1234 5678 9012 3456"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <CreditCardIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <TextField
                        fullWidth
                        label="Expiration Date"
                        variant="outlined"
                        placeholder="MM/YY"
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                        fullWidth
                        label="CVC"
                        variant="outlined"
                        placeholder="123"
                      />
                    </Grid>
                  </Grid>
                </Box>
              )}
              
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Order Summary
                </Typography>
                <Box sx={{ p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body1">Regular Home Cleaning</Typography>
                    <Typography variant="body1">$120.00</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">Service Fee</Typography>
                    <Typography variant="body2" color="text.secondary">$10.00</Typography>
                  </Box>
                  <Divider sx={{ my: 1 }} />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="subtitle1" fontWeight="bold">Total</Typography>
                    <Typography variant="subtitle1" fontWeight="bold" color="primary.main">$130.00</Typography>
                  </Box>
                </Box>
              </Box>
              
              <FormControlLabel
                control={
                  <Checkbox 
                    checked={agreeTerms} 
                    onChange={handleAgreeTermsChange} 
                  />
                }
                label="I agree to the terms of service and cancellation policy"
                sx={{ mb: 2 }}
              />
              
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <LockIcon color="primary" sx={{ mr: 1, fontSize: 20 }} />
                <Typography variant="body2" color="text.secondary">
                  Your payment information is encrypted and secure
                </Typography>
              </Box>
            </Box>
          )}
        </Paper>

        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            variant="outlined"
          >
            Back
          </Button>
          <Button
            variant="contained"
            onClick={activeStep === steps.length - 1 ? null : handleNext}
            disabled={(activeStep === 3 && !agreeTerms) || 
                     (activeStep === 0 && !selectedService) || 
                     (activeStep === 1 && (!selectedDate || !selectedTime)) || 
                     (activeStep === 2 && !address)}
          >
            {activeStep === steps.length - 1 ? 'Complete Booking' : 'Continue'}
          </Button>
        </Box>
      </Container>

      {/* Trust Badges */}
      <Box sx={{ bgcolor: 'grey.100', py: 4 }}>
        <Container maxWidth="md">
          <Grid container spacing={3} justifyContent="center" textAlign="center">
            <Grid item xs={12} sm={4}>
              <Box>
                <LockIcon color="primary" sx={{ fontSize: 40 }} />
                <Typography variant="h6" fontWeight="bold" gutterBottom>
                  Secure Payments
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Your payment information is encrypted and secure
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box>
                <PaymentIcon color="primary" sx={{ fontSize: 40 }} />
                <Typography variant="h6" fontWeight="bold" gutterBottom>
                  Money-Back Guarantee
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Not satisfied? We'll make it right or refund your payment
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box>
                <CalendarMonthIcon color="primary" sx={{ fontSize: 40 }} />
                <Typography variant="h6" fontWeight="bold" gutterBottom>
                  Free Rescheduling
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Plans change? Reschedule up to 24 hours before your appointment
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </Box>
  );
};

export default BookingPage;
