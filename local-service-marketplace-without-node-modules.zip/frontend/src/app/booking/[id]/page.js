import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  TextField, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem,
  Paper,
  Stepper,
  Step,
  StepLabel,
  FormHelperText,
  Alert,
  Divider,
  CircularProgress
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { useParams } from 'next/navigation';
import { useProviders } from '../../context/ProviderContext';
import { useServices } from '../../context/ServiceContext';
import { useBookings } from '../../context/BookingContext';
import { usePayments } from '../../context/PaymentContext';
import { useAuth } from '../../context/AuthContext';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

export default function BookingPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { fetchProvider, currentProvider, loading: providerLoading } = useProviders();
  const { fetchService, currentService, loading: serviceLoading } = useServices();
  const { createNewBooking } = useBookings();
  const { createBookingPayment, confirmPaymentIntent } = usePayments();
  
  const [activeStep, setActiveStep] = useState(0);
  const [bookingData, setBookingData] = useState({
    provider: id,
    service: '',
    date: null,
    startTime: null,
    endTime: null,
    duration: 60,
    price: 0,
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'USA'
    },
    notes: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [services, setServices] = useState([]);
  const [clientSecret, setClientSecret] = useState('');
  const [paymentError, setPaymentError] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [bookingId, setBookingId] = useState(null);
  
  const stripe = useStripe();
  const elements = useElements();

  useEffect(() => {
    if (id) {
      fetchProvider(id);
    }
  }, [id, fetchProvider]);

  useEffect(() => {
    if (currentProvider) {
      // Fetch services for this provider
      setServices(currentProvider.services || []);
    }
  }, [currentProvider]);

  useEffect(() => {
    if (user) {
      // Pre-fill address from user profile if available
      if (user.address) {
        setBookingData(prev => ({
          ...prev,
          address: {
            street: user.address.street || '',
            city: user.address.city || '',
            state: user.address.state || '',
            zipCode: user.address.zipCode || '',
            country: user.address.country || 'USA'
          }
        }));
      }
    }
  }, [user]);

  useEffect(() => {
    // When service is selected, update duration and price
    if (bookingData.service && services.length > 0) {
      const selectedService = services.find(s => s._id === bookingData.service);
      if (selectedService) {
        setBookingData(prev => ({
          ...prev,
          duration: selectedService.duration || 60,
          price: selectedService.price || 0
        }));
      }
    }
  }, [bookingData.service, services]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setBookingData({
        ...bookingData,
        [parent]: {
          ...bookingData[parent],
          [child]: value
        }
      });
    } else {
      setBookingData({
        ...bookingData,
        [name]: value
      });
    }
    
    // Clear error for this field if it exists
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handleDateChange = (date) => {
    setBookingData({
      ...bookingData,
      date
    });
    
    if (errors.date) {
      setErrors({
        ...errors,
        date: ''
      });
    }
  };

  const handleTimeChange = (time, field) => {
    setBookingData({
      ...bookingData,
      [field]: time
    });
    
    if (errors[field]) {
      setErrors({
        ...errors,
        [field]: ''
      });
    }
  };

  const validateStep = () => {
    const newErrors = {};
    
    if (activeStep === 0) {
      if (!bookingData.service) {
        newErrors.service = 'Please select a service';
      }
      if (!bookingData.date) {
        newErrors.date = 'Please select a date';
      }
      if (!bookingData.startTime) {
        newErrors.startTime = 'Please select a start time';
      }
    } else if (activeStep === 1) {
      if (!bookingData.address.street) {
        newErrors['address.street'] = 'Please enter your street address';
      }
      if (!bookingData.address.city) {
        newErrors['address.city'] = 'Please enter your city';
      }
      if (!bookingData.address.state) {
        newErrors['address.state'] = 'Please enter your state';
      }
      if (!bookingData.address.zipCode) {
        newErrors['address.zipCode'] = 'Please enter your ZIP code';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleCreateBooking = async () => {
    setLoading(true);
    
    try {
      // Format the data for API
      const formattedData = {
        ...bookingData,
        date: bookingData.date.toISOString(),
        startTime: formatTime(bookingData.startTime),
        endTime: calculateEndTime(bookingData.startTime, bookingData.duration)
      };
      
      // Create booking
      const result = await createNewBooking(formattedData);
      
      if (result.success) {
        setBookingId(result.data._id);
        
        // Create payment intent
        const paymentResult = await createBookingPayment(result.data._id);
        
        if (paymentResult.success) {
          setClientSecret(paymentResult.clientSecret);
          handleNext();
        } else {
          setErrors({ submit: paymentResult.error || 'Failed to create payment' });
        }
      } else {
        setErrors({ submit: result.error || 'Failed to create booking' });
      }
    } catch (error) {
      setErrors({ submit: 'An unexpected error occurred' });
      console.error('Booking error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }
    
    setLoading(true);
    setPaymentError('');
    
    try {
      const cardElement = elements.getElement(CardElement);
      
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            name: user.name,
            email: user.email,
            address: {
              line1: bookingData.address.street,
              city: bookingData.address.city,
              state: bookingData.address.state,
              postal_code: bookingData.address.zipCode,
              country: bookingData.address.country
            }
          }
        }
      });
      
      if (error) {
        setPaymentError(error.message);
      } else if (paymentIntent.status === 'succeeded') {
        // Confirm payment on backend
        const confirmResult = await confirmPaymentIntent(paymentIntent.id);
        
        if (confirmResult.success) {
          setPaymentSuccess(true);
          handleNext();
        } else {
          setPaymentError(confirmResult.error || 'Failed to confirm payment');
        }
      }
    } catch (error) {
      setPaymentError('An unexpected error occurred');
      console.error('Payment error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (date) => {
    if (!date) return '';
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  const calculateEndTime = (startTime, durationMinutes) => {
    if (!startTime) return '';
    const endTime = new Date(startTime);
    endTime.setMinutes(endTime.getMinutes() + durationMinutes);
    return formatTime(endTime);
  };

  const steps = ['Select Service & Time', 'Location Details', 'Review & Pay', 'Confirmation'];

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.service}>
                <InputLabel id="service-label">Select Service</InputLabel>
                <Select
                  labelId="service-label"
                  id="service"
                  name="service"
                  value={bookingData.service}
                  label="Select Service"
                  onChange={handleChange}
                >
                  {services.map((service) => (
                    <MenuItem key={service._id} value={service._id}>
                      {service.name} - ${service.price}
                    </MenuItem>
                  ))}
                </Select>
                {errors.service && <FormHelperText>{errors.service}</FormHelperText>}
              </FormControl>
            </Grid>
            
            <Grid item xs={12}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Select Date"
                  value={bookingData.date}
                  onChange={handleDateChange}
                  renderInput={(params) => (
                    <TextField 
                      {...params} 
                      fullWidth 
                      error={!!errors.date}
                      helperText={errors.date}
                    />
                  )}
                  disablePast
                  minDate={new Date()}
                />
              </LocalizationProvider>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <TimePicker
                  label="Start Time"
                  value={bookingData.startTime}
                  onChange={(time) => handleTimeChange(time, 'startTime')}
                  renderInput={(params) => (
                    <TextField 
                      {...params} 
                      fullWidth 
                      error={!!errors.startTime}
                      helperText={errors.startTime}
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Duration (minutes)"
                type="number"
                name="duration"
                value={bookingData.duration}
                onChange={handleChange}
                InputProps={{
                  readOnly: true,
                }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes or Special Requirements"
                name="notes"
                multiline
                rows={4}
                value={bookingData.notes}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        );
      case 1:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Street Address"
                name="address.street"
                value={bookingData.address.street}
                onChange={handleChange}
                error={!!errors['address.street']}
                helperText={errors['address.street']}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="City"
                name="address.city"
                value={bookingData.address.city}
                onChange={handleChange}
                error={!!errors['address.city']}
                helperText={errors['address.city']}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="State"
                name="address.state"
                value={bookingData.address.state}
                onChange={handleChange}
                error={!!errors['address.state']}
                helperText={errors['address.state']}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="ZIP Code"
                name="address.zipCode"
                value={bookingData.address.zipCode}
                onChange={handleChange}
                error={!!errors['address.zipCode']}
                helperText={errors['address.zipCode']}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel id="country-label">Country</InputLabel>
                <Select
                  labelId="country-label"
                  id="country"
                  name="address.country"
                  value={bookingData.address.country}
                  label="Country"
                  onChange={handleChange}
                >
                  <MenuItem value="USA">United States</MenuItem>
                  <MenuItem value="Canada">Canada</MenuItem>
                  <MenuItem value="Mexico">Mexico</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        );
      case 2:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Paper sx={{ p: 3, mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Booking Summary
                </Typography>
                
                <Grid container spacing={2}>
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Provider:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {currentProvider?.businessName}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Service:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {services.find(s => s._id === bookingData.service)?.name}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Date:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {bookingData.date?.toLocaleDateString()}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Time:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {bookingData.startTime?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Duration:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {bookingData.duration} minutes
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">
                      Address:
                    </Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">
                      {bookingData.address.street}, {bookingData.address.city}, {bookingData.address.state} {bookingData.address.zipCode}
                    </Typography>
                  </Grid>
                </Grid>
                
                <Divider sx={{ my: 2 }} />
                
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      Total:
                    </Typography>
                  </Grid>
                  <Grid item xs={6} sx={{ textAlign: 'right' }}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      ${bookingData.price}
                    </Typography>
                  </Grid>
                </Grid>
              </Paper>
              
              {errors.submit && (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {errors.submit}
                </Alert>
              )}
              
              {clientSecret ? (
                <form onSubmit={handlePaymentSubmit}>
                  <Typography variant="h6" gutterBottom>
                    Payment Details
                  </Typography>
                  
                  <Box sx={{ mb: 3 }}>
                    <CardElement
                      options={{
                        style: {
                          base: {
                            fontSize: '16px',
                            color: '#424770',
                            '::placeholder': {
                              color: '#aab7c4',
                            },
                          },
                          invalid: {
                            color: '#9e2146',
                          },
                        },
                      }}
                    />
                  </Box>
                  
                  {paymentError && (
                    <Alert severity="error" sx={{ mb: 3 }}>
                      {paymentError}
                    </Alert>
                  )}
                  
                  <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    fullWidth
                    disabled={!stripe || loading}
                  >
                    {loading ? <CircularProgress size={24} /> : `Pay $${bookingData.price}`}
                  </Button>
                </form>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  onClick={handleCreateBooking}
                  disabled={loading}
                >
                  {loading ? <CircularProgress size={24} /> : 'Proceed to Payment'}
                </Button>
              )}
            </Grid>
          </Grid>
        );
      case 3:
        return (
          <Box sx={{ textAlign: 'center', py: 3 }}>
            <Typography variant="h5" gutterBottom color="primary">
              Booking Confirmed!
            </Typography>
            
            <Typography variant="body1" paragraph>
              Your booking with {currentProvider?.businessName} has been confirmed.
            </Typography>
            
            <Typography variant="body1" paragraph>
              We've sent a confirmation email to your registered email address.
            </Typography>
            
            <Box sx={{ mt: 4 }}>
              <Button variant="contained" color="primary" href="/dashboard">
                Go to Dashboard
              </Button>
            </Box>
          </Box>
        );
      default:
        return null;
    }
  };

  if (providerLoading) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Typography>Loading...</Typography>
      </Container>
    );
  }

  if (!currentProvider) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Typography>Provider not found</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h4" gutterBottom align="center">
          Book Service
        </Typography>
        
        <Typography variant="h6" gutterBottom align="center" color="text.secondary">
          {currentProvider.businessName}
        </Typography>
        
        <Stepper activeStep={activeStep} sx={{ mb: 4, pt: 2 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        <Box>
          {renderStepContent(activeStep)}
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
            <Button
              variant="outlined"
              onClick={handleBack}
              disabled={activeStep === 0 || activeStep === 3}
            >
              Back
            </Button>
            
            {activeStep < 2 && (
              <Button
                variant="contained"
                onClick={handleNext}
              >
                Next
              </Button>
            )}
          </Box>
        </Box>
      </Paper>
    </Container>
  );
}
