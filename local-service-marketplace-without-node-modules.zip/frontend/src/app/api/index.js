import axios from 'axios';

// Create axios instance with base URL
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add request interceptor to add auth token to requests
api.interceptors.request.use(
  (config) => {
    // Get token from localStorage if in browser environment
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle 401 Unauthorized errors (token expired)
    if (error.response && error.response.status === 401) {
      if (typeof window !== 'undefined') {
        // Clear localStorage and redirect to login
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const registerUser = async (userData) => {
  const response = await api.post('/auth/register', userData);
  return response.data;
};

export const loginUser = async (credentials) => {
  const response = await api.post('/auth/login', credentials);
  return response.data;
};

export const logoutUser = async () => {
  const response = await api.get('/auth/logout');
  return response.data;
};

export const getCurrentUser = async () => {
  const response = await api.get('/auth/me');
  return response.data;
};

// Provider API calls
export const getProviders = async (params) => {
  const response = await api.get('/providers', { params });
  return response.data;
};

export const getProvider = async (id) => {
  const response = await api.get(`/providers/${id}`);
  return response.data;
};

export const createProvider = async (providerData) => {
  const response = await api.post('/providers', providerData);
  return response.data;
};

export const updateProvider = async (id, providerData) => {
  const response = await api.put(`/providers/${id}`, providerData);
  return response.data;
};

export const getTopRatedProviders = async () => {
  const response = await api.get('/providers/top-rated');
  return response.data;
};

export const getProvidersByService = async (serviceId) => {
  const response = await api.get(`/providers/service/${serviceId}`);
  return response.data;
};

export const getProvidersByLocation = async (zipcode, distance) => {
  const response = await api.get(`/providers/location/${zipcode}/${distance}`);
  return response.data;
};

// Service API calls
export const getServices = async (params) => {
  const response = await api.get('/services', { params });
  return response.data;
};

export const getService = async (id) => {
  const response = await api.get(`/services/${id}`);
  return response.data;
};

export const getPopularServices = async () => {
  const response = await api.get('/services/popular');
  return response.data;
};

export const getServicesByCategory = async (categoryId) => {
  const response = await api.get(`/services/category/${categoryId}`);
  return response.data;
};

// Booking API calls
export const createBooking = async (bookingData) => {
  const response = await api.post('/bookings', bookingData);
  return response.data;
};

export const getUserBookings = async () => {
  const response = await api.get('/bookings/user');
  return response.data;
};

export const getProviderBookings = async () => {
  const response = await api.get('/bookings/provider');
  return response.data;
};

export const getBooking = async (id) => {
  const response = await api.get(`/bookings/${id}`);
  return response.data;
};

export const confirmBooking = async (id) => {
  const response = await api.put(`/bookings/${id}/confirm`);
  return response.data;
};

export const completeBooking = async (id) => {
  const response = await api.put(`/bookings/${id}/complete`);
  return response.data;
};

export const cancelBooking = async (id, reason) => {
  const response = await api.put(`/bookings/${id}/cancel`, { reason });
  return response.data;
};

// Review API calls
export const getProviderReviews = async (providerId) => {
  const response = await api.get(`/reviews/provider/${providerId}`);
  return response.data;
};

export const createReview = async (reviewData) => {
  const response = await api.post('/reviews', reviewData);
  return response.data;
};

// Payment API calls
export const createPaymentIntent = async (paymentData) => {
  const response = await api.post('/payments/create-payment-intent', paymentData);
  return response.data;
};

export const confirmPayment = async (paymentIntentId) => {
  const response = await api.post(`/payments/confirm/${paymentIntentId}`);
  return response.data;
};

export const getPaymentHistory = async () => {
  const response = await api.get('/payments/history');
  return response.data;
};

export const createSubscription = async (paymentMethodId) => {
  const response = await api.post('/payments/subscription/create', { paymentMethodId });
  return response.data;
};

export const cancelSubscription = async () => {
  const response = await api.post('/payments/subscription/cancel');
  return response.data;
};

export default api;
