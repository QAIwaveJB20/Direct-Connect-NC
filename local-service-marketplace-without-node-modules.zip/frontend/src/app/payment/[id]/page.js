"use client";

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  TextField,
  Paper,
  Divider,
  CircularProgress,
  Alert
} from '@mui/material';
import { useParams, useRouter } from 'next/navigation';
import { useAuth } from '../../context/AuthContext';
import { useProviders } from '../../context/ProviderContext';
import { useBookings } from '../../context/BookingContext';
import { usePayments } from '../../context/PaymentContext';
import StripePaymentForm from '../../components/payment/StripePaymentForm';

export default function PaymentPage() {
  const { id } = useParams(); // booking id
  const router = useRouter();
  const { user } = useAuth();
  const { fetchBooking, currentBooking, loading: bookingLoading } = useBookings();
  const { fetchProvider, currentProvider, loading: providerLoading } = useProviders();
  const { confirmPaymentIntent } = usePayments();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  
  useEffect(() => {
    const loadBookingData = async () => {
      setLoading(true);
      try {
        if (id) {
          // Fetch booking details
          const booking = await fetchBooking(id);
          
          if (booking) {
            // Fetch provider details
            await fetchProvider(booking.provider);
          }
        }
      } catch (err) {
        setError('Failed to load booking details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadBookingData();
  }, [id, fetchBooking, fetchProvider]);

  const handlePaymentSuccess = async (paymentIntent) => {
    try {
      setLoading(true);
      
      // Confirm payment on backend
      const result = await confirmPaymentIntent(paymentIntent.id);
      
      if (result.success) {
        setSuccess(true);
        
        // Redirect to confirmation page after 2 seconds
        setTimeout(() => {
          router.push(`/booking/confirmation/${id}`);
        }, 2000);
      } else {
        setError(result.error || 'Failed to confirm payment');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentError = (errorMessage) => {
    setError(errorMessage);
  };

  if (loading || bookingLoading || providerLoading) {
    return (
      <Container maxWidth="md" sx={{ py: 8, textAlign: 'center' }}>
        <CircularProgress />
        <Typography sx={{ mt: 2 }}>Loading payment details...</Typography>
      </Container>
    );
  }

  if (!currentBooking) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="error">Booking not found</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  if (currentBooking.paymentStatus === 'paid') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="info">This booking has already been paid</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Typography variant="h4" gutterBottom align="center">
          Complete Your Payment
        </Typography>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        {success && (
          <Alert severity="success" sx={{ mb: 3 }}>
            Payment successful! Redirecting to confirmation page...
          </Alert>
        )}
        
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Booking Summary
            </Typography>
            
            <Card variant="outlined" sx={{ mb: 3 }}>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Provider:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {currentProvider?.businessName}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Service:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {currentBooking.service?.name}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Date:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {new Date(currentBooking.date).toLocaleDateString()}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Time:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {currentBooking.startTime}
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Duration:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {currentBooking.duration} minutes
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={5}>
                    <Typography variant="body2" color="text.secondary">
                      Address:
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    <Typography variant="body2" fontWeight="medium">
                      {currentBooking.address.street}, {currentBooking.address.city}, {currentBooking.address.state} {currentBooking.address.zipCode}
                    </Typography>
                  </Grid>
                </Grid>
                
                <Divider sx={{ my: 2 }} />
                
                <Grid container>
                  <Grid item xs={6}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      Total:
                    </Typography>
                  </Grid>
                  <Grid item xs={6} sx={{ textAlign: 'right' }}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      ${currentBooking.price}
                    </Typography>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
            
            <Typography variant="body2" color="text.secondary" paragraph>
              Your booking will be confirmed immediately after successful payment.
            </Typography>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Payment Method
            </Typography>
            
            {!success && (
              <StripePaymentForm 
                amount={currentBooking.price}
                paymentType="booking"
                bookingId={id}
                onSuccess={handlePaymentSuccess}
                onError={handlePaymentError}
                buttonText="Pay"
              />
            )}
            
            <Box sx={{ mt: 3, textAlign: 'center' }}>
              <Button 
                variant="text" 
                onClick={() => router.push('/dashboard')}
                disabled={loading || success}
              >
                Cancel and return to dashboard
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
}
