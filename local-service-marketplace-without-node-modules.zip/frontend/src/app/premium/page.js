"use client";

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Paper,
  Divider,
  CircularProgress,
  Alert,
  List,
  ListItem,
  ListItemText,
  Chip
} from '@mui/material';
import { useRouter } from 'next/navigation';
import { useAuth } from '../context/AuthContext';
import { usePayments } from '../context/PaymentContext';
import StripePaymentForm from '../components/payment/StripePaymentForm';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import StarIcon from '@mui/icons-material/Star';

export default function PremiumPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { createSubscriptionWithPaymentMethod, confirmPaymentIntent } = usePayments();
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  
  const plans = {
    monthly: {
      name: 'Monthly Premium',
      price: 29.99,
      features: [
        'Verified badge on profile',
        'Priority placement in search results',
        'Detailed analytics dashboard',
        'Featured provider status',
        'Unlimited service listings',
        'Customer insights and reports',
        'Premium customer support'
      ],
      billing: 'Billed monthly'
    },
    annual: {
      name: 'Annual Premium',
      price: 299.99,
      features: [
        'All Monthly Premium features',
        'Two months free ($59.98 savings)',
        'Early access to new features',
        'Premium marketing tools',
        'Business growth consultation',
        'Dedicated account manager'
      ],
      billing: 'Billed annually'
    }
  };

  const handlePlanSelect = (plan) => {
    setSelectedPlan(plan);
  };

  const handlePaymentSuccess = async (paymentIntent) => {
    try {
      setLoading(true);
      
      // Confirm payment on backend
      const result = await confirmPaymentIntent(paymentIntent.id);
      
      if (result.success) {
        setSuccess(true);
        
        // Redirect to dashboard after 3 seconds
        setTimeout(() => {
          router.push('/dashboard');
        }, 3000);
      } else {
        setError(result.error || 'Failed to confirm subscription');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentError = (errorMessage) => {
    setError(errorMessage);
  };

  if (!user || user.role !== 'provider') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="error">Only service providers can access premium plans</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  if (user.provider?.isPremium && !success) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <CheckCircleOutlineIcon color="success" sx={{ fontSize: 64, mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            You're Already Premium
          </Typography>
          <Typography variant="body1" paragraph>
            Your account already has premium status. You can manage your subscription from your dashboard.
          </Typography>
          <Button 
            variant="contained" 
            onClick={() => router.push('/dashboard')}
          >
            Go to Dashboard
          </Button>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      {success ? (
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <CheckCircleOutlineIcon color="success" sx={{ fontSize: 64, mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            Subscription Successful!
          </Typography>
          <Typography variant="body1" paragraph>
            Thank you for subscribing to our Premium plan. Your account has been upgraded and all premium features are now available.
          </Typography>
          <Typography variant="body1" paragraph>
            You will be redirected to your dashboard in a few seconds.
          </Typography>
          <Button 
            variant="contained" 
            onClick={() => router.push('/dashboard')}
          >
            Go to Dashboard Now
          </Button>
        </Paper>
      ) : (
        <>
          <Typography variant="h3" align="center" gutterBottom>
            Upgrade to Premium
          </Typography>
          <Typography variant="h6" align="center" color="text.secondary" sx={{ mb: 6 }}>
            Boost your visibility and grow your business with premium features
          </Typography>
          
          {error && (
            <Alert severity="error" sx={{ mb: 4 }}>
              {error}
            </Alert>
          )}
          
          <Grid container spacing={4}>
            {/* Plan Selection */}
            <Grid item xs={12} md={7}>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <Paper 
                    elevation={selectedPlan === 'monthly' ? 8 : 1} 
                    sx={{ 
                      p: 3, 
                      height: '100%', 
                      borderRadius: 2,
                      border: selectedPlan === 'monthly' ? 2 : 0,
                      borderColor: 'primary.main',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-4px)',
                        boxShadow: 6
                      }
                    }}
                    onClick={() => handlePlanSelect('monthly')}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Typography variant="h5" fontWeight="bold">
                        Monthly
                      </Typography>
                      <Chip 
                        label="Popular" 
                        color="primary" 
                        size="small"
                      />
                    </Box>
                    
                    <Typography variant="h4" fontWeight="bold" sx={{ mb: 1 }}>
                      ${plans.monthly.price}
                      <Typography variant="body1" component="span" color="text.secondary">
                        /month
                      </Typography>
                    </Typography>
                    
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                      {plans.monthly.billing}
                    </Typography>
                    
                    <Divider sx={{ mb: 2 }} />
                    
                    <List dense>
                      {plans.monthly.features.map((feature, index) => (
                        <ListItem key={index} disableGutters>
                          <StarIcon color="primary" fontSize="small" sx={{ mr: 1 }} />
                          <ListItemText primary={feature} />
                        </ListItem>
                      ))}
                    </List>
                  </Paper>
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <Paper 
                    elevation={selectedPlan === 'annual' ? 8 : 1} 
                    sx={{ 
                      p: 3, 
                      height: '100%', 
                      borderRadius: 2,
                      border: selectedPlan === 'annual' ? 2 : 0,
                      borderColor: 'primary.main',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-4px)',
                        boxShadow: 6
                      }
                    }}
                    onClick={() => handlePlanSelect('annual')}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                      <Typography variant="h5" fontWeight="bold">
                        Annual
                      </Typography>
                      <Chip 
                        label="Best Value" 
                        color="secondary" 
                        size="small"
                      />
                    </Box>
                    
                    <Typography variant="h4" fontWeight="bold" sx={{ mb: 1 }}>
                      ${plans.annual.price}
                      <Typography variant="body1" component="span" color="text.secondary">
                        /year
                      </Typography>
                    </Typography>
                    
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                      {plans.annual.billing}
                    </Typography>
                    
                    <Divider sx={{ mb: 2 }} />
                    
                    <List dense>
                      {plans.annual.features.map((feature, index) => (
                        <ListItem key={index} disableGutters>
                          <StarIcon color="secondary" fontSize="small" sx={{ mr: 1 }} />
                          <ListItemText primary={feature} />
                        </ListItem>
                      ))}
                    </List>
                  </Paper>
                </Grid>
              </Grid>
            </Grid>
            
            {/* Payment Form */}
            <Grid item xs={12} md={5}>
              <Paper elevation={3} sx={{ p: 3, borderRadius: 2 }}>
                <Typography variant="h5" gutterBottom>
                  {plans[selectedPlan].name}
                </Typography>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
                  <Typography variant="body1">Subscription Fee:</Typography>
                  <Typography variant="body1" fontWeight="bold">
                    ${plans[selectedPlan].price}
                  </Typography>
                </Box>
                
                <Divider sx={{ mb: 3 }} />
                
                <Typography variant="h6" gutterBottom>
                  Payment Details
                </Typography>
                
                <StripePaymentForm 
                  amount={plans[selectedPlan].price}
                  paymentType="subscription"
                  onSuccess={handlePaymentSuccess}
                  onError={handlePaymentError}
                  buttonText="Subscribe to"
                />
                
                <Typography variant="body2" color="text.secondary" sx={{ mt: 3, textAlign: 'center' }}>
                  By subscribing, you agree to our Terms of Service and Privacy Policy.
                  You can cancel your subscription at any time from your dashboard.
                </Typography>
              </Paper>
            </Grid>
          </Grid>
          
          <Box sx={{ mt: 6 }}>
            <Typography variant="h5" gutterBottom>
              Frequently Asked Questions
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                      What happens after I subscribe?
                    </Typography>
                    <Typography variant="body2">
                      Your account will be immediately upgraded to premium status, and all premium features will be available to you. Your profile will display a verified badge, and you'll receive priority placement in search results.
                    </Typography>
                  </CardContent>
                </Card>
                
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                      Can I cancel my subscription?
                    </Typography>
                    <Typography variant="body2">
                      Yes, you can cancel your subscription at any time from your dashboard. Your premium benefits will continue until the end of your current billing period.
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Card variant="outlined" sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                      Is there a free trial?
                    </Typography>
                    <Typography variant="body2">
                      We don't currently offer a free trial, but we do have a 30-day money-back guarantee if you're not satisfied with the premium features.
                    </Typography>
                  </CardContent>
                </Card>
                
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                      What payment methods do you accept?
                    </Typography>
                    <Typography variant="body2">
                      We accept all major credit and debit cards, including Visa, Mastercard, American Express, and Discover.
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Box>
        </>
      )}
    </Container>
  );
}
