import React, { useEffect } from 'react';
import { Box, Typography, Container, Button, CircularProgress } from '@mui/material';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import { usePayments } from '../context/PaymentContext';
import { useAuth } from '../context/AuthContext';

const StripePaymentForm = ({ 
  amount, 
  paymentType, 
  bookingId = null, 
  onSuccess, 
  onError,
  buttonText = 'Pay Now'
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const { createBookingPayment, createProviderSubscription, createVerificationPayment } = usePayments();
  const { user } = useAuth();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [clientSecret, setClientSecret] = React.useState('');

  useEffect(() => {
    const getPaymentIntent = async () => {
      setLoading(true);
      setError(null);
      
      try {
        let response;
        
        switch (paymentType) {
          case 'booking':
            if (!bookingId) {
              throw new Error('Booking ID is required for booking payments');
            }
            response = await createBookingPayment(bookingId);
            break;
          case 'subscription':
            response = await createProviderSubscription();
            break;
          case 'verification':
            response = await createVerificationPayment();
            break;
          default:
            throw new Error(`Invalid payment type: ${paymentType}`);
        }
        
        if (response.success) {
          setClientSecret(response.clientSecret);
        } else {
          setError(response.error || 'Failed to create payment intent');
        }
      } catch (err) {
        setError(err.message || 'An unexpected error occurred');
        if (onError) onError(err.message || 'An unexpected error occurred');
      } finally {
        setLoading(false);
      }
    };
    
    getPaymentIntent();
  }, [paymentType, bookingId, createBookingPayment, createProviderSubscription, createVerificationPayment, onError]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    if (!stripe || !elements) {
      // Stripe.js has not loaded yet
      return;
    }
    
    setLoading(true);
    setError(null);
    
    const cardElement = elements.getElement(CardElement);
    
    try {
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            name: user?.name || '',
            email: user?.email || '',
            address: user?.address ? {
              line1: user.address.street || '',
              city: user.address.city || '',
              state: user.address.state || '',
              postal_code: user.address.zipCode || '',
              country: user.address.country || 'US'
            } : undefined
          }
        }
      });
      
      if (error) {
        setError(error.message);
        if (onError) onError(error.message);
      } else if (paymentIntent.status === 'succeeded') {
        if (onSuccess) onSuccess(paymentIntent);
      }
    } catch (err) {
      setError(err.message || 'An unexpected error occurred');
      if (onError) onError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="sm">
      <form onSubmit={handleSubmit}>
        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Payment Details
          </Typography>
          
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
                invalid: {
                  color: '#9e2146',
                },
              },
            }}
          />
        </Box>
        
        {error && (
          <Box sx={{ mb: 2, color: 'error.main' }}>
            <Typography variant="body2">{error}</Typography>
          </Box>
        )}
        
        <Button
          type="submit"
          variant="contained"
          color="primary"
          fullWidth
          disabled={!stripe || loading || !clientSecret}
          sx={{ py: 1.5 }}
        >
          {loading ? <CircularProgress size={24} /> : `${buttonText} $${amount}`}
        </Button>
      </form>
    </Container>
  );
};

export default StripePaymentForm;
