import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  TextField,
  InputAdornment,
  Paper,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Badge,
  Tab,
  Tabs,
  IconButton,
  Menu,
  MenuItem
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import StarIcon from '@mui/icons-material/Star';
import VerifiedIcon from '@mui/icons-material/Verified';
import SortIcon from '@mui/icons-material/Sort';
import TuneIcon from '@mui/icons-material/Tune';

const SearchResultsPage = () => {
  const [tabValue, setTabValue] = useState(0);
  const [sortAnchorEl, setSortAnchorEl] = useState(null);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [sortOption, setSortOption] = useState('relevance');
  const [priceFilter, setPriceFilter] = useState('all');
  const [ratingFilter, setRatingFilter] = useState('all');

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSortClick = (event) => {
    setSortAnchorEl(event.currentTarget);
  };

  const handleSortClose = () => {
    setSortAnchorEl(null);
  };

  const handleFilterClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleSortChange = (option) => {
    setSortOption(option);
    handleSortClose();
  };

  const handlePriceFilterChange = (option) => {
    setPriceFilter(option);
  };

  const handleRatingFilterChange = (option) => {
    setRatingFilter(option);
  };

  return (
    <Box>
      {/* Search Header */}
      <Box sx={{ bgcolor: 'primary.main', color: 'white', py: 4 }}>
        <Container maxWidth="lg">
          <Typography variant="h4" component="h1" gutterBottom fontWeight="bold" textAlign="center">
            Cleaning Services in Charlotte
          </Typography>
          
          <Paper
            component="form"
            sx={{ p: '2px 4px', display: 'flex', alignItems: 'center', maxWidth: 600, mx: 'auto', mt: 3 }}
          >
            <InputAdornment position="start" sx={{ pl: 2 }}>
              <SearchIcon />
            </InputAdornment>
            <TextField
              fullWidth
              placeholder="Search for services"
              variant="standard"
              InputProps={{ disableUnderline: true }}
              defaultValue="Cleaning"
            />
            <Divider sx={{ height: 28, m: 0.5 }} orientation="vertical" />
            <InputAdornment position="start" sx={{ pl: 2 }}>
              <LocationOnIcon />
            </InputAdornment>
            <TextField
              fullWidth
              placeholder="Location"
              variant="standard"
              InputProps={{ disableUnderline: true }}
              defaultValue="Charlotte, NC"
            />
            <Button sx={{ p: '10px' }} aria-label="search">
              <SearchIcon />
            </Button>
          </Paper>
        </Container>
      </Box>

      {/* Search Results */}
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Grid container spacing={4}>
          {/* Filters Sidebar */}
          <Grid item xs={12} md={3}>
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom fontWeight="bold">
                  Filters
                </Typography>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="subtitle2" gutterBottom fontWeight="bold">
                    Service Type
                  </Typography>
                  <List dense>
                    {[
                      { label: 'Home Cleaning', count: 42 },
                      { label: 'Deep Cleaning', count: 28 },
                      { label: 'Move-In/Move-Out', count: 15 },
                      { label: 'Office Cleaning', count: 9 },
                      { label: 'Post-Construction', count: 5 }
                    ].map((item, index) => (
                      <ListItem key={index} sx={{ px: 0 }}>
                        <ListItemText 
                          primary={
                            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                              <Typography variant="body2">{item.label}</Typography>
                              <Typography variant="body2" color="text.secondary">({item.count})</Typography>
                            </Box>
                          } 
                        />
                      </ListItem>
                    ))}
                  </List>
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="subtitle2" gutterBottom fontWeight="bold">
                    Price Range
                  </Typography>
                  <List dense>
                    {[
                      { label: 'All Prices', value: 'all' },
                      { label: 'Under $50', value: 'under_50' },
                      { label: '$50 - $100', value: '50_100' },
                      { label: '$100 - $200', value: '100_200' },
                      { label: 'Over $200', value: 'over_200' }
                    ].map((item, index) => (
                      <ListItem 
                        key={index} 
                        sx={{ 
                          px: 0,
                          color: priceFilter === item.value ? 'primary.main' : 'inherit',
                          fontWeight: priceFilter === item.value ? 'bold' : 'normal'
                        }}
                        onClick={() => handlePriceFilterChange(item.value)}
                        button
                      >
                        <ListItemText primary={item.label} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="subtitle2" gutterBottom fontWeight="bold">
                    Rating
                  </Typography>
                  <List dense>
                    {[
                      { label: 'Any Rating', value: 'all' },
                      { label: '4 Stars & Up', value: '4_up' },
                      { label: '3 Stars & Up', value: '3_up' },
                      { label: 'Top Rated', value: 'top' }
                    ].map((item, index) => (
                      <ListItem 
                        key={index} 
                        sx={{ 
                          px: 0,
                          color: ratingFilter === item.value ? 'primary.main' : 'inherit',
                          fontWeight: ratingFilter === item.value ? 'bold' : 'normal'
                        }}
                        onClick={() => handleRatingFilterChange(item.value)}
                        button
                      >
                        <ListItemText primary={item.label} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="subtitle2" gutterBottom fontWeight="bold">
                    Availability
                  </Typography>
                  <List dense>
                    {[
                      { label: 'Any Time' },
                      { label: 'Today' },
                      { label: 'Tomorrow' },
                      { label: 'This Week' },
                      { label: 'This Weekend' }
                    ].map((item, index) => (
                      <ListItem key={index} sx={{ px: 0 }} button>
                        <ListItemText primary={item.label} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Box>
                  <Typography variant="subtitle2" gutterBottom fontWeight="bold">
                    Provider Type
                  </Typography>
                  <List dense>
                    {[
                      { label: 'All Providers' },
                      { label: 'Premium Providers' },
                      { label: 'Top Rated' },
                      { label: 'Verified Only' }
                    ].map((item, index) => (
                      <ListItem key={index} sx={{ px: 0 }} button>
                        <ListItemText primary={item.label} />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Results */}
          <Grid item xs={12} md={9}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6" component="h2">
                42 results found
              </Typography>
              
              <Box sx={{ display: 'flex' }}>
                <Button 
                  startIcon={<SortIcon />} 
                  onClick={handleSortClick}
                  sx={{ mr: 1 }}
                >
                  Sort
                </Button>
                <Menu
                  anchorEl={sortAnchorEl}
                  open={Boolean(sortAnchorEl)}
                  onClose={handleSortClose}
                >
                  <MenuItem 
                    onClick={() => handleSortChange('relevance')}
                    selected={sortOption === 'relevance'}
                  >
                    Relevance
                  </MenuItem>
                  <MenuItem 
                    onClick={() => handleSortChange('rating')}
                    selected={sortOption === 'rating'}
                  >
                    Highest Rating
                  </MenuItem>
                  <MenuItem 
                    onClick={() => handleSortChange('price_low')}
                    selected={sortOption === 'price_low'}
                  >
                    Price: Low to High
                  </MenuItem>
                  <MenuItem 
                    onClick={() => handleSortChange('price_high')}
                    selected={sortOption === 'price_high'}
                  >
                    Price: High to Low
                  </MenuItem>
                </Menu>
                
                <Button 
                  startIcon={<TuneIcon />} 
                  onClick={handleFilterClick}
                  sx={{ display: { xs: 'flex', md: 'none' } }}
                >
                  Filter
                </Button>
                <Menu
                  anchorEl={filterAnchorEl}
                  open={Boolean(filterAnchorEl)}
                  onClose={handleFilterClose}
                  sx={{ display: { xs: 'block', md: 'none' } }}
                >
                  {/* Mobile filters would go here */}
                  <MenuItem>Price: All</MenuItem>
                  <MenuItem>Rating: Any</MenuItem>
                  <MenuItem>Availability: Any Time</MenuItem>
                </Menu>
              </Box>
            </Box>
            
            <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
              <Tabs value={tabValue} onChange={handleTabChange} aria-label="search result tabs">
                <Tab label="All" id="tab-0" />
                <Tab label="Premium" id="tab-1" />
                <Tab label="Verified" id="tab-2" />
                <Tab label="Available Today" id="tab-3" />
              </Tabs>
            </Box>
            
            {/* Provider List */}
            <Box>
              {[
                { 
                  id: 1,
                  name: 'Elite Cleaners', 
                  image: '/images/provider1.jpg', 
                  rating: 4.9, 
                  reviews: 243,
                  verified: true, 
                  premium: true,
                  distance: '5 miles',
                  price: 'From $120',
                  description: 'Professional home cleaning services with eco-friendly products and exceptional attention to detail.',
                  services: ['Regular Cleaning', 'Deep Cleaning', 'Move-In/Out']
                },
                { 
                  id: 2,
                  name: 'Sparkle Home Services', 
                  image: '/images/provider2.jpg', 
                  rating: 4.7, 
                  reviews: 187,
                  verified: true, 
                  premium: false,
                  distance: '3 miles',
                  price: 'From $95',
                  description: 'Reliable and thorough cleaning services for homes and apartments. Satisfaction guaranteed.',
                  services: ['Regular Cleaning', 'Deep Cleaning', 'Office Cleaning']
                },
                { 
                  id: 3,
                  name: 'Crystal Clear Cleaning', 
                  image: '/images/provider3.jpg', 
                  rating: 4.8, 
                  reviews: 156,
                  verified: true, 
                  premium: true,
                  distance: '7 miles',
                  price: 'From $110',
                  description: 'Experienced team providing spotless results for residential and commercial properties.',
                  services: ['Regular Cleaning', 'Commercial', 'Post-Construction']
                },
                { 
                  id: 4,
                  name: 'Maid Perfect', 
                  image: '/images/provider4.jpg', 
                  rating: 4.6, 
                  reviews: 98,
                  verified: false, 
                  premium: false,
                  distance: '4 miles',
                  price: 'From $85',
                  description: 'Affordable and quality cleaning services for busy professionals and families.',
                  services: ['Regular Cleaning', 'Deep Cleaning']
                },
                { 
                  id: 5,
                  name: 'Clean Sweep Pros', 
                  image: '/images/provider5.jpg', 
                  rating: 4.5, 
                  reviews: 76,
                  verified: true, 
                  premium: false,
                  distance: '6 miles',
                  price: 'From $100',
                  description: 'Detailed cleaning services with a focus on natural cleaning products and sustainability.',
                  services: ['Regular Cleaning', 'Green Cleaning', 'Move-In/Out']
                }
              ].map((provider, index) => (
                <Card key={index} sx={{ mb: 3, position: 'relative', overflow: 'visible' }}>
                  {provider.premium && (
                    <Box 
                      sx={{ 
                        position: 'absolute', 
                        top: 16, 
                        right: -8,
                        zIndex: 1,
                        bgcolor: 'secondary.main',
                        color: 'white',
                        py: 0.5,
                        px: 2,
                        borderRadius: '4px',
                        boxShadow: 2,
                        fontWeight: 'bold',
                        fontSize: '0.75rem',
                        transform: 'rotate(0deg)'
                      }}
                    >
                      PREMIUM
                    </Box>
                  )}
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={3}>
                        <Box sx={{ position: 'relative' }}>
                          <Avatar 
                            src={provider.image} 
                            alt={provider.name}
                            variant="rounded"
                            sx={{ 
                              width: '100%', 
                              height: 'auto',
                              aspectRatio: '1/1',
                              bgcolor: 'grey.300' // Placeholder color
                            }}
                          />
                          {provider.verified && (
                            <Badge 
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              badgeContent={
                                <VerifiedIcon 
                                  color="primary" 
                                  sx={{ 
                                    fontSize: 24,
                                    bgcolor: 'white',
                                    borderRadius: '50%'
                                  }} 
                                />
                              }
                              sx={{
                                position: 'absolute',
                                bottom: -8,
                                right: -8
                              }}
                            />
                          )}
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Typography variant="h6" component="h3" fontWeight="bold">
                          {provider.name}
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Rating value={provider.rating} precision={0.1} size="small" readOnly />
                          <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                            {provider.rating} ({provider.reviews} reviews)
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          <LocationOnIcon sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                          {provider.distance} away
                        </Typography>
                        <Typography variant="body2" paragraph>
                          {provider.description}
                        </Typography>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                          {provider.services.map((service, i) => (
                            <Chip 
                              key={i} 
                              label={service} 
                              size="small" 
                              variant="outlined"
                            />
                          ))}
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={3} sx={{ display: 'flex', flexDirection: 'column', alignItems: { xs: 'flex-start', sm: 'flex-end' }, justifyContent: 'space-between' }}>
                        <Typography variant="h6" color="primary.main" fontWeight="bold" sx={{ mb: 1 }}>
                          {provider.price}
                        </Typography>
                        <Box>
                          <Button 
                            variant="contained" 
                            fullWidth
                            sx={{ mb: 1 }}
                            href={`/providers/${provider.id}`}
                          >
                            View Profile
                          </Button>
                          <Button 
                            variant="outlined" 
                            fullWidth
                            href={`/booking/${provider.id}`}
                          >
                            Book Now
                          </Button>
                        </Box>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              ))}
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Button variant="outlined" size="large">
                Load More Results
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default SearchResultsPage;
