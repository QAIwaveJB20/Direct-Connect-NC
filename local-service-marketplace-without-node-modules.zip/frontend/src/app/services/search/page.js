import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  Button, 
  TextField,
  InputAdornment,
  IconButton,
  Paper,
  Chip,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Pagination
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import FilterListIcon from '@mui/icons-material/FilterList';
import StarIcon from '@mui/icons-material/Star';
import VerifiedIcon from '@mui/icons-material/Verified';
import { useRouter } from 'next/navigation';
import { useServices } from '../../context/ServiceContext';
import { useProviders } from '../../context/ProviderContext';
import Link from 'next/link';

export default function SearchPage() {
  const router = useRouter();
  const { fetchServices, services, loading: servicesLoading } = useServices();
  const { fetchProviders, providers, loading: providersLoading } = useProviders();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('');
  const [sortBy, setSortBy] = useState('rating');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [searchResults, setSearchResults] = useState([]);
  const [totalResults, setTotalResults] = useState(0);
  const [categories, setCategories] = useState([
    { id: 'home-services', name: 'Home Services' },
    { id: 'personal-care', name: 'Personal Care' },
    { id: 'professional', name: 'Professional Services' },
    { id: 'events', name: 'Events & Entertainment' },
    { id: 'tech', name: 'Tech Services' },
    { id: 'education', name: 'Education & Tutoring' }
  ]);
  
  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        // Fetch services and providers
        await fetchServices();
        await fetchProviders();
      } catch (error) {
        console.error('Error loading search data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadInitialData();
  }, [fetchServices, fetchProviders]);
  
  useEffect(() => {
    // Combine and filter results based on search criteria
    if (providers.length > 0 || services.length > 0) {
      let results = [...providers];
      
      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        results = results.filter(provider => 
          provider.businessName.toLowerCase().includes(query) ||
          provider.description.toLowerCase().includes(query) ||
          provider.services.some(service => 
            service.name.toLowerCase().includes(query) ||
            service.description.toLowerCase().includes(query)
          )
        );
      }
      
      // Filter by location
      if (location) {
        const locationQuery = location.toLowerCase();
        results = results.filter(provider => 
          provider.address.city.toLowerCase().includes(locationQuery) ||
          provider.address.state.toLowerCase().includes(locationQuery) ||
          provider.address.zipCode.includes(locationQuery)
        );
      }
      
      // Filter by category
      if (category) {
        results = results.filter(provider => 
          provider.categories.includes(category) ||
          provider.services.some(service => service.category === category)
        );
      }
      
      // Filter by price range
      results = results.filter(provider => 
        provider.services.some(service => 
          service.price >= priceRange[0] && service.price <= priceRange[1]
        )
      );
      
      // Sort results
      switch (sortBy) {
        case 'rating':
          results.sort((a, b) => (b.averageRating || 0) - (a.averageRating || 0));
          break;
        case 'price-low':
          results.sort((a, b) => {
            const aMinPrice = Math.min(...a.services.map(s => s.price));
            const bMinPrice = Math.min(...b.services.map(s => s.price));
            return aMinPrice - bMinPrice;
          });
          break;
        case 'price-high':
          results.sort((a, b) => {
            const aMaxPrice = Math.max(...a.services.map(s => s.price));
            const bMaxPrice = Math.max(...b.services.map(s => s.price));
            return bMaxPrice - aMaxPrice;
          });
          break;
        case 'popularity':
          results.sort((a, b) => (b.totalBookings || 0) - (a.totalBookings || 0));
          break;
        default:
          break;
      }
      
      setTotalResults(results.length);
      
      // Paginate results
      const resultsPerPage = 10;
      const startIndex = (page - 1) * resultsPerPage;
      const paginatedResults = results.slice(startIndex, startIndex + resultsPerPage);
      
      setSearchResults(paginatedResults);
    }
  }, [providers, services, searchQuery, location, category, sortBy, priceRange, page]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1); // Reset to first page on new search
  };

  const handlePageChange = (event, value) => {
    setPage(value);
    window.scrollTo(0, 0);
  };

  const handleCategoryClick = (categoryId) => {
    setCategory(categoryId);
    setPage(1);
  };

  const handleSortChange = (event) => {
    setSortBy(event.target.value);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setLocation('');
    setCategory('');
    setSortBy('rating');
    setPriceRange([0, 1000]);
    setPage(1);
  };

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      {/* Search Header */}
      <Paper 
        component="form" 
        onSubmit={handleSearch}
        sx={{ 
          p: 3, 
          mb: 4, 
          borderRadius: 2,
          boxShadow: 3
        }}
      >
        <Typography variant="h4" gutterBottom>
          Find Local Service Providers
        </Typography>
        
        <Grid container spacing={2}>
          <Grid item xs={12} sm={5}>
            <TextField
              fullWidth
              placeholder="What service are you looking for?"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          
          <Grid item xs={12} sm={5}>
            <TextField
              fullWidth
              placeholder="Location (City, State, or ZIP)"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LocationOnIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          
          <Grid item xs={12} sm={2}>
            <Button 
              type="submit" 
              variant="contained" 
              fullWidth 
              sx={{ height: '100%' }}
            >
              Search
            </Button>
          </Grid>
        </Grid>
      </Paper>
      
      {/* Categories */}
      <Paper sx={{ p: 3, mb: 4, borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom>
          Popular Categories
        </Typography>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2 }}>
          {categories.map((cat) => (
            <Chip
              key={cat.id}
              label={cat.name}
              onClick={() => handleCategoryClick(cat.id)}
              color={category === cat.id ? 'primary' : 'default'}
              clickable
            />
          ))}
          
          {category && (
            <Chip
              label="Clear Filters"
              onClick={handleClearFilters}
              variant="outlined"
              color="primary"
            />
          )}
        </Box>
      </Paper>
      
      {/* Search Results */}
      <Grid container spacing={4}>
        {/* Filters Sidebar */}
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
              <FilterListIcon sx={{ mr: 1 }} />
              Filters
            </Typography>
            
            <Divider sx={{ my: 2 }} />
            
            <Typography variant="subtitle1" gutterBottom>
              Sort By
            </Typography>
            <FormControl fullWidth size="small" sx={{ mb: 3 }}>
              <Select
                value={sortBy}
                onChange={handleSortChange}
              >
                <MenuItem value="rating">Highest Rated</MenuItem>
                <MenuItem value="price-low">Price: Low to High</MenuItem>
                <MenuItem value="price-high">Price: High to Low</MenuItem>
                <MenuItem value="popularity">Most Popular</MenuItem>
              </Select>
            </FormControl>
            
            <Typography variant="subtitle1" gutterBottom>
              Category
            </Typography>
            <FormControl fullWidth size="small" sx={{ mb: 3 }}>
              <Select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                displayEmpty
              >
                <MenuItem value="">All Categories</MenuItem>
                {categories.map((cat) => (
                  <MenuItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <Typography variant="subtitle1" gutterBottom>
              Price Range
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <TextField
                size="small"
                type="number"
                label="Min"
                value={priceRange[0]}
                onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
                InputProps={{
                  startAdornment: <InputAdornment position="start">$</InputAdornment>,
                }}
              />
              <Typography>to</Typography>
              <TextField
                size="small"
                type="number"
                label="Max"
                value={priceRange[1]}
                onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000])}
                InputProps={{
                  startAdornment: <InputAdornment position="start">$</InputAdornment>,
                }}
              />
            </Box>
            
            <Button 
              variant="outlined" 
              fullWidth
              onClick={handleClearFilters}
            >
              Clear All Filters
            </Button>
          </Paper>
        </Grid>
        
        {/* Results List */}
        <Grid item xs={12} md={9}>
          <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography>
              {loading ? 'Searching...' : `${totalResults} results found`}
            </Typography>
          </Box>
          
          {loading ? (
            <Typography>Loading results...</Typography>
          ) : searchResults.length > 0 ? (
            <>
              {searchResults.map((provider) => (
                <Paper 
                  key={provider._id} 
                  sx={{ 
                    mb: 3, 
                    overflow: 'hidden',
                    borderRadius: 2,
                    transition: 'transform 0.2s, box-shadow 0.2s',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: 4
                    }
                  }}
                >
                  <Grid container>
                    <Grid item xs={12} sm={4} md={3}>
                      <Box sx={{ position: 'relative', height: '100%', minHeight: 200 }}>
                        <CardMedia
                          component="img"
                          image={provider.photos?.[0] || "/images/default-service.jpg"}
                          alt={provider.businessName}
                          sx={{ height: '100%', objectFit: 'cover' }}
                        />
                        {provider.isPremium && (
                          <Chip 
                            label="Premium" 
                            color="secondary" 
                            size="small"
                            sx={{ 
                              position: 'absolute', 
                              top: 8, 
                              left: 8 
                            }}
                          />
                        )}
                      </Box>
                    </Grid>
                    
                    <Grid item xs={12} sm={8} md={9}>
                      <CardContent sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Typography variant="h6" component="h2" sx={{ mr: 1 }}>
                            {provider.businessName}
                          </Typography>
                          {provider.verificationStatus === 'verified' && (
                            <VerifiedIcon color="primary" fontSize="small" />
                          )}
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                            <StarIcon color="warning" fontSize="small" sx={{ mr: 0.5 }} />
                            <Typography variant="body2">
                              {provider.averageRating?.toFixed(1) || 'New'} ({provider.totalReviews || 0})
                            </Typography>
                          </Box>
                          
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <LocationOnIcon fontSize="small" sx={{ mr: 0.5 }} />
                            <Typography variant="body2">
                              {provider.address?.city}, {provider.address?.state}
                            </Typography>
                          </Box>
                        </Box>
                        
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                          {provider.description?.substring(0, 150)}
                          {provider.description?.length > 150 ? '...' : ''}
                        </Typography>
                        
                        <Box sx={{ mt: 'auto' }}>
                          <Typography variant="subtitle2" gutterBottom>
                            Services:
                          </Typography>
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                            {provider.services?.slice(0, 3).map((service) => (
                              <Chip 
                                key={service._id} 
                                label={`${service.name} - $${service.price}`} 
                                size="small" 
                                variant="outlined"
                              />
                            ))}
                            {provider.services?.length > 3 && (
                              <Chip 
                                label={`+${provider.services.length - 3} more`} 
                                size="small" 
                                variant="outlined"
                              />
                            )}
                          </Box>
                          
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant="subtitle1" fontWeight="bold">
                              Starting at ${Math.min(...provider.services?.map(s => s.price) || [0])}
                            </Typography>
                            
                            <Button 
                              variant="contained" 
                              component={Link}
                              href={`/providers/${provider._id}`}
                            >
                              View Details
                            </Button>
                          </Box>
                        </Box>
                      </CardContent>
                    </Grid>
                  </Grid>
                </Paper>
              ))}
              
              {/* Pagination */}
              {totalResults > 10 && (
                <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                  <Pagination 
                    count={Math.ceil(totalResults / 10)} 
                    page={page} 
                    onChange={handlePageChange}
                    color="primary"
                  />
                </Box>
              )}
            </>
          ) : (
            <Paper sx={{ p: 4, textAlign: 'center' }}>
              <Typography variant="h6" gutterBottom>
                No results found
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Try adjusting your search criteria or browse all services
              </Typography>
              <Button 
                variant="contained" 
                sx={{ mt: 2 }}
                onClick={handleClearFilters}
              >
                Clear Filters
              </Button>
            </Paper>
          )}
        </Grid>
      </Grid>
    </Container>
  );
}
