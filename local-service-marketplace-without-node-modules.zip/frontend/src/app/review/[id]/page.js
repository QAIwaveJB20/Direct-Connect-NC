"use client";

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  TextField,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Rating,
  Avatar
} from '@mui/material';
import { useParams, useRouter } from 'next/navigation';
import { useAuth } from '../../context/AuthContext';
import { useProviders } from '../../context/ProviderContext';
import { useBookings } from '../../context/BookingContext';

export default function ReviewFormPage() {
  const { id } = useParams(); // booking id
  const router = useRouter();
  const { user } = useAuth();
  const { fetchBooking, currentBooking, loading: bookingLoading } = useBookings();
  const { fetchProvider, currentProvider, loading: providerLoading } = useProviders();
  
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [reviewData, setReviewData] = useState({
    rating: 0,
    comment: '',
    serviceQuality: 0,
    punctuality: 0,
    professionalism: 0,
    valueForMoney: 0
  });
  
  useEffect(() => {
    const loadBookingData = async () => {
      setLoading(true);
      try {
        if (id) {
          // Fetch booking details
          const booking = await fetchBooking(id);
          
          if (booking) {
            // Fetch provider details
            await fetchProvider(booking.provider);
          }
        }
      } catch (err) {
        setError('Failed to load booking details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadBookingData();
  }, [id, fetchBooking, fetchProvider]);

  const handleRatingChange = (field, value) => {
    setReviewData({
      ...reviewData,
      [field]: value
    });
  };

  const handleCommentChange = (e) => {
    setReviewData({
      ...reviewData,
      comment: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (reviewData.rating === 0) {
      setError('Please provide an overall rating');
      return;
    }
    
    setSubmitting(true);
    setError(null);
    
    try {
      // Calculate average rating from all categories
      const averageRating = (
        reviewData.rating + 
        reviewData.serviceQuality + 
        reviewData.punctuality + 
        reviewData.professionalism + 
        reviewData.valueForMoney
      ) / 5;
      
      // Submit review to backend
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          booking: id,
          provider: currentBooking.provider,
          rating: reviewData.rating,
          comment: reviewData.comment,
          categories: {
            serviceQuality: reviewData.serviceQuality,
            punctuality: reviewData.punctuality,
            professionalism: reviewData.professionalism,
            valueForMoney: reviewData.valueForMoney
          }
        })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess(true);
        
        // Redirect to dashboard after 2 seconds
        setTimeout(() => {
          router.push('/dashboard');
        }, 2000);
      } else {
        setError(data.error || 'Failed to submit review');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || bookingLoading || providerLoading) {
    return (
      <Container maxWidth="md" sx={{ py: 8, textAlign: 'center' }}>
        <CircularProgress />
        <Typography sx={{ mt: 2 }}>Loading booking details...</Typography>
      </Container>
    );
  }

  if (!currentBooking) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="error">Booking not found</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  if (currentBooking.status !== 'completed') {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="info">You can only review completed bookings</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  if (currentBooking.isReviewed) {
    return (
      <Container maxWidth="md" sx={{ py: 8 }}>
        <Alert severity="info">You have already reviewed this booking</Alert>
        <Button 
          variant="contained" 
          sx={{ mt: 2 }}
          onClick={() => router.push('/dashboard')}
        >
          Return to Dashboard
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Typography variant="h4" gutterBottom align="center">
          Review Your Experience
        </Typography>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        {success && (
          <Alert severity="success" sx={{ mb: 3 }}>
            Your review has been submitted successfully! Redirecting to dashboard...
          </Alert>
        )}
        
        <Box sx={{ mb: 4 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item>
              <Avatar 
                src={currentProvider?.photos?.[0] || "/images/default-avatar.jpg"} 
                sx={{ width: 64, height: 64 }}
              />
            </Grid>
            <Grid item xs>
              <Typography variant="h6">
                {currentProvider?.businessName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {currentBooking.service?.name} on {new Date(currentBooking.date).toLocaleDateString()}
              </Typography>
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ mb: 4 }} />
        
        <form onSubmit={handleSubmit}>
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Overall Rating
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Rating
                  name="rating"
                  value={reviewData.rating}
                  onChange={(event, newValue) => {
                    handleRatingChange('rating', newValue);
                  }}
                  size="large"
                  precision={0.5}
                />
                <Typography variant="body2" sx={{ ml: 2 }}>
                  {reviewData.rating > 0 ? `${reviewData.rating} stars` : 'Select a rating'}
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1" gutterBottom>
                Service Quality
              </Typography>
              <Rating
                name="serviceQuality"
                value={reviewData.serviceQuality}
                onChange={(event, newValue) => {
                  handleRatingChange('serviceQuality', newValue);
                }}
                precision={0.5}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1" gutterBottom>
                Punctuality
              </Typography>
              <Rating
                name="punctuality"
                value={reviewData.punctuality}
                onChange={(event, newValue) => {
                  handleRatingChange('punctuality', newValue);
                }}
                precision={0.5}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1" gutterBottom>
                Professionalism
              </Typography>
              <Rating
                name="professionalism"
                value={reviewData.professionalism}
                onChange={(event, newValue) => {
                  handleRatingChange('professionalism', newValue);
                }}
                precision={0.5}
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1" gutterBottom>
                Value for Money
              </Typography>
              <Rating
                name="valueForMoney"
                value={reviewData.valueForMoney}
                onChange={(event, newValue) => {
                  handleRatingChange('valueForMoney', newValue);
                }}
                precision={0.5}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="subtitle1" gutterBottom>
                Your Review
              </Typography>
              <TextField
                fullWidth
                multiline
                rows={4}
                placeholder="Share your experience with this service provider..."
                value={reviewData.comment}
                onChange={handleCommentChange}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button
                  variant="outlined"
                  onClick={() => router.push('/dashboard')}
                  disabled={submitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={submitting || success}
                >
                  {submitting ? <CircularProgress size={24} /> : 'Submit Review'}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Container>
  );
}
