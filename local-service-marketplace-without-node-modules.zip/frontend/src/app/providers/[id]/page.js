import React from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  Button, 
  Avatar, 
  Rating, 
  Chip,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Tab,
  Tabs
} from '@mui/material';
import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useProviders } from '../../context/ProviderContext';
import { useServices } from '../../context/ServiceContext';
import { useBookings } from '../../context/BookingContext';
import { useAuth } from '../../context/AuthContext';
import VerifiedIcon from '@mui/icons-material/Verified';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import LanguageIcon from '@mui/icons-material/Language';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import BookingForm from '../../components/booking/BookingForm';
import ReviewList from '../../components/reviews/ReviewList';
import ServiceList from '../../components/services/ServiceList';

export default function ProviderDetailPage() {
  const { id } = useParams();
  const { fetchProvider, currentProvider, loading: providerLoading } = useProviders();
  const { isAuthenticated } = useAuth();
  const [tabValue, setTabValue] = useState(0);
  const [showBookingForm, setShowBookingForm] = useState(false);
  
  useEffect(() => {
    if (id) {
      fetchProvider(id);
    }
  }, [id, fetchProvider]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleBookNowClick = () => {
    setShowBookingForm(true);
    setTabValue(2); // Switch to booking tab
  };

  if (providerLoading) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography>Loading provider details...</Typography>
      </Container>
    );
  }

  if (!currentProvider) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography>Provider not found</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      {/* Provider Header */}
      <Paper elevation={2} sx={{ mb: 4, overflow: 'hidden' }}>
        <Box sx={{ 
          height: 200, 
          bgcolor: 'primary.main', 
          position: 'relative',
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("/images/provider-banner.jpg")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }} />
        
        <Box sx={{ p: 3, position: 'relative' }}>
          <Avatar 
            src={currentProvider.photos?.[0] || "/images/default-avatar.jpg"} 
            sx={{ 
              width: 120, 
              height: 120, 
              border: '4px solid white', 
              position: 'absolute', 
              top: -60,
              left: 24,
              boxShadow: 2
            }}
          />
          
          <Box sx={{ ml: { xs: 0, sm: 18 }, mt: { xs: 8, sm: 0 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
              <Typography variant="h4" component="h1" fontWeight="bold">
                {currentProvider.businessName}
              </Typography>
              {currentProvider.verificationStatus === 'verified' && (
                <Chip 
                  icon={<VerifiedIcon />} 
                  label="Verified" 
                  color="primary" 
                  size="small"
                />
              )}
              {currentProvider.isPremium && (
                <Chip 
                  label="Premium" 
                  color="secondary" 
                  size="small"
                />
              )}
            </Box>
            
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
              <Rating 
                value={currentProvider.averageRating || 0} 
                precision={0.5} 
                readOnly 
              />
              <Typography variant="body2" sx={{ ml: 1 }}>
                {currentProvider.averageRating?.toFixed(1) || 'No ratings'} ({currentProvider.totalReviews || 0} reviews)
              </Typography>
            </Box>
            
            <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
              {currentProvider.description}
            </Typography>
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mt: 2 }}>
              <Button 
                variant="contained" 
                color="primary"
                onClick={handleBookNowClick}
                disabled={!isAuthenticated}
              >
                Book Now
              </Button>
              <Button variant="outlined">
                Contact
              </Button>
              {!isAuthenticated && (
                <Typography variant="caption" color="error" sx={{ width: '100%', mt: 1 }}>
                  Please sign in to book this provider
                </Typography>
              )}
            </Box>
          </Box>
        </Box>
      </Paper>
      
      {/* Provider Details Tabs */}
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="provider details tabs"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab label="Overview" />
            <Tab label="Services" />
            <Tab label="Book" />
            <Tab label="Reviews" />
            <Tab label="Gallery" />
          </Tabs>
        </Box>
        
        {/* Overview Tab */}
        <TabPanel value={tabValue} index={0}>
          <Grid container spacing={4}>
            <Grid item xs={12} md={8}>
              <Typography variant="h6" gutterBottom fontWeight="bold">
                About {currentProvider.businessName}
              </Typography>
              <Typography paragraph>
                {currentProvider.description}
              </Typography>
              
              <Divider sx={{ my: 3 }} />
              
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Service Area
              </Typography>
              <Typography paragraph>
                We provide services within {currentProvider.serviceArea || 25} miles of our location.
              </Typography>
              
              <Divider sx={{ my: 3 }} />
              
              <Typography variant="h6" gutterBottom fontWeight="bold">
                Availability
              </Typography>
              <Grid container spacing={2}>
                {Object.entries(currentProvider.availability || {}).map(([day, schedule]) => (
                  <Grid item xs={6} sm={4} md={3} key={day}>
                    <Paper sx={{ p: 2, textAlign: 'center' }}>
                      <Typography variant="subtitle1" fontWeight="bold" sx={{ textTransform: 'capitalize' }}>
                        {day}
                      </Typography>
                      {schedule.isAvailable ? (
                        <Typography variant="body2">
                          {schedule.start} - {schedule.end}
                        </Typography>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          Closed
                        </Typography>
                      )}
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom fontWeight="bold">
                  Contact Information
                </Typography>
                <List>
                  <ListItem disableGutters>
                    <ListItemIcon sx={{ minWidth: 40 }}>
                      <LocationOnIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Address" 
                      secondary={`${currentProvider.address?.street}, ${currentProvider.address?.city}, ${currentProvider.address?.state} ${currentProvider.address?.zipCode}`} 
                    />
                  </ListItem>
                  <ListItem disableGutters>
                    <ListItemIcon sx={{ minWidth: 40 }}>
                      <PhoneIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Phone" 
                      secondary={currentProvider.phone} 
                    />
                  </ListItem>
                  <ListItem disableGutters>
                    <ListItemIcon sx={{ minWidth: 40 }}>
                      <EmailIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Email" 
                      secondary={currentProvider.email} 
                    />
                  </ListItem>
                  {currentProvider.website && (
                    <ListItem disableGutters>
                      <ListItemIcon sx={{ minWidth: 40 }}>
                        <LanguageIcon color="primary" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Website" 
                        secondary={currentProvider.website} 
                      />
                    </ListItem>
                  )}
                </List>
                
                <Divider sx={{ my: 2 }} />
                
                <Typography variant="h6" gutterBottom fontWeight="bold">
                  Business Hours
                </Typography>
                <List dense>
                  {Object.entries(currentProvider.availability || {}).map(([day, schedule]) => (
                    <ListItem disableGutters key={day}>
                      <ListItemText 
                        primary={<Typography sx={{ textTransform: 'capitalize' }}>{day}</Typography>}
                        secondary={schedule.isAvailable ? `${schedule.start} - ${schedule.end}` : 'Closed'}
                      />
                    </ListItem>
                  ))}
                </List>
              </Paper>
            </Grid>
          </Grid>
        </TabPanel>
        
        {/* Services Tab */}
        <TabPanel value={tabValue} index={1}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Services Offered
          </Typography>
          <ServiceList providerId={id} />
        </TabPanel>
        
        {/* Booking Tab */}
        <TabPanel value={tabValue} index={2}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Book an Appointment
          </Typography>
          {isAuthenticated ? (
            <BookingForm providerId={id} />
          ) : (
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="h6" gutterBottom>
                Please sign in to book this provider
              </Typography>
              <Button variant="contained" href="/login">
                Sign In
              </Button>
            </Paper>
          )}
        </TabPanel>
        
        {/* Reviews Tab */}
        <TabPanel value={tabValue} index={3}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Customer Reviews
          </Typography>
          <ReviewList providerId={id} />
        </TabPanel>
        
        {/* Gallery Tab */}
        <TabPanel value={tabValue} index={4}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Photo Gallery
          </Typography>
          <Grid container spacing={2}>
            {(currentProvider.photos || []).length > 0 ? (
              (currentProvider.photos || []).map((photo, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Card>
                    <CardMedia
                      component="img"
                      height="200"
                      image={photo || "/images/default-service.jpg"}
                      alt={`${currentProvider.businessName} photo ${index + 1}`}
                    />
                  </Card>
                </Grid>
              ))
            ) : (
              <Grid item xs={12}>
                <Typography>No photos available</Typography>
              </Grid>
            )}
          </Grid>
        </TabPanel>
      </Box>
    </Container>
  );
}

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`provider-tabpanel-${index}`}
      aria-labelledby={`provider-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}
