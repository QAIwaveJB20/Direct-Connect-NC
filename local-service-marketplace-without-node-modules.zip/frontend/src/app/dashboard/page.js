import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Paper,
  Tabs,
  Tab,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Avatar,
  Chip,
  Badge,
  CircularProgress
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BookOnlineIcon from '@mui/icons-material/BookOnline';
import ReviewsIcon from '@mui/icons-material/Reviews';
import PaymentIcon from '@mui/icons-material/Payment';
import SettingsIcon from '@mui/icons-material/Settings';
import PersonIcon from '@mui/icons-material/Person';
import { useAuth } from '../context/AuthContext';
import { useBookings } from '../context/BookingContext';
import { usePayments } from '../context/PaymentContext';
import BookingList from '../components/booking/BookingList';
import PaymentHistory from '../components/payment/PaymentHistory';
import UserProfile from '../components/user/UserProfile';

export default function DashboardPage() {
  const { user, isProvider, isAdmin } = useAuth();
  const { fetchUserBookings, fetchProviderBookings, userBookings, providerBookings, loading: bookingsLoading } = useBookings();
  const { fetchPaymentHistory, paymentHistory, loading: paymentsLoading } = usePayments();
  
  const [tabValue, setTabValue] = useState(0);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadDashboardData = async () => {
      setLoading(true);
      
      try {
        // Load bookings based on user role
        if (isProvider) {
          await fetchProviderBookings();
        } else {
          await fetchUserBookings();
        }
        
        // Load payment history
        await fetchPaymentHistory();
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    if (user) {
      loadDashboardData();
    }
  }, [user, isProvider, fetchUserBookings, fetchProviderBookings, fetchPaymentHistory]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  if (!user) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography>Please log in to view your dashboard</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Grid container spacing={4}>
        {/* Sidebar */}
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Avatar 
                src={user.avatar || "/images/default-avatar.jpg"} 
                sx={{ width: 64, height: 64, mr: 2 }}
              />
              <Box>
                <Typography variant="h6">{user.name}</Typography>
                <Chip 
                  label={user.role === 'provider' ? 'Service Provider' : user.role === 'admin' ? 'Admin' : 'Customer'} 
                  size="small" 
                  color={user.role === 'provider' ? 'primary' : user.role === 'admin' ? 'secondary' : 'default'}
                />
              </Box>
            </Box>
            
            <Divider sx={{ mb: 2 }} />
            
            <List component="nav" disablePadding>
              <ListItem 
                button 
                selected={tabValue === 0}
                onClick={() => setTabValue(0)}
                sx={{ borderRadius: 1, mb: 1 }}
              >
                <ListItemIcon>
                  <DashboardIcon />
                </ListItemIcon>
                <ListItemText primary="Dashboard" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === 1}
                onClick={() => setTabValue(1)}
                sx={{ borderRadius: 1, mb: 1 }}
              >
                <ListItemIcon>
                  <BookOnlineIcon />
                </ListItemIcon>
                <ListItemText primary="Bookings" />
                <Badge 
                  badgeContent={isProvider ? providerBookings.length : userBookings.length} 
                  color="primary"
                  sx={{ mr: 1 }}
                />
              </ListItem>
              
              {isProvider && (
                <ListItem 
                  button 
                  selected={tabValue === 2}
                  onClick={() => setTabValue(2)}
                  sx={{ borderRadius: 1, mb: 1 }}
                >
                  <ListItemIcon>
                    <ReviewsIcon />
                  </ListItemIcon>
                  <ListItemText primary="Reviews" />
                </ListItem>
              )}
              
              <ListItem 
                button 
                selected={tabValue === isProvider ? 3 : 2}
                onClick={() => setTabValue(isProvider ? 3 : 2)}
                sx={{ borderRadius: 1, mb: 1 }}
              >
                <ListItemIcon>
                  <PaymentIcon />
                </ListItemIcon>
                <ListItemText primary="Payments" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === isProvider ? 4 : 3}
                onClick={() => setTabValue(isProvider ? 4 : 3)}
                sx={{ borderRadius: 1, mb: 1 }}
              >
                <ListItemIcon>
                  <PersonIcon />
                </ListItemIcon>
                <ListItemText primary="Profile" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === isProvider ? 5 : 4}
                onClick={() => setTabValue(isProvider ? 5 : 4)}
                sx={{ borderRadius: 1 }}
              >
                <ListItemIcon>
                  <SettingsIcon />
                </ListItemIcon>
                <ListItemText primary="Settings" />
              </ListItem>
            </List>
          </Paper>
          
          {isProvider && !user.provider?.isPremium && (
            <Paper sx={{ p: 3, bgcolor: 'primary.light', color: 'primary.contrastText' }}>
              <Typography variant="h6" gutterBottom>
                Upgrade to Premium
              </Typography>
              <Typography variant="body2" paragraph>
                Get more visibility, featured listings, and advanced tools.
              </Typography>
              <Button 
                variant="contained" 
                color="secondary" 
                fullWidth
                href="/premium"
              >
                Upgrade Now
              </Button>
            </Paper>
          )}
        </Grid>
        
        {/* Main Content */}
        <Grid item xs={12} md={9}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              {/* Dashboard Tab */}
              {tabValue === 0 && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    Dashboard
                  </Typography>
                  
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12} sm={6} md={4}>
                      <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                          {isProvider ? 'Total Bookings' : 'My Bookings'}
                        </Typography>
                        <Typography variant="h3" color="primary">
                          {isProvider ? providerBookings.length : userBookings.length}
                        </Typography>
                      </Paper>
                    </Grid>
                    
                    <Grid item xs={12} sm={6} md={4}>
                      <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                          Upcoming
                        </Typography>
                        <Typography variant="h3" color="primary">
                          {isProvider 
                            ? providerBookings.filter(b => b.status === 'pending' || b.status === 'confirmed').length 
                            : userBookings.filter(b => b.status === 'pending' || b.status === 'confirmed').length}
                        </Typography>
                      </Paper>
                    </Grid>
                    
                    <Grid item xs={12} sm={6} md={4}>
                      <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                          Completed
                        </Typography>
                        <Typography variant="h3" color="primary">
                          {isProvider 
                            ? providerBookings.filter(b => b.status === 'completed').length 
                            : userBookings.filter(b => b.status === 'completed').length}
                        </Typography>
                      </Paper>
                    </Grid>
                  </Grid>
                  
                  <Paper sx={{ p: 3, mb: 4 }}>
                    <Typography variant="h6" gutterBottom>
                      Recent Bookings
                    </Typography>
                    
                    {isProvider ? (
                      providerBookings.length > 0 ? (
                        <BookingList 
                          bookings={providerBookings.slice(0, 5)} 
                          isProvider={true}
                        />
                      ) : (
                        <Typography>No bookings yet</Typography>
                      )
                    ) : (
                      userBookings.length > 0 ? (
                        <BookingList 
                          bookings={userBookings.slice(0, 5)} 
                          isProvider={false}
                        />
                      ) : (
                        <Typography>No bookings yet</Typography>
                      )
                    )}
                    
                    {(isProvider ? providerBookings.length : userBookings.length) > 5 && (
                      <Box sx={{ textAlign: 'center', mt: 2 }}>
                        <Button 
                          variant="outlined" 
                          onClick={() => setTabValue(1)}
                        >
                          View All Bookings
                        </Button>
                      </Box>
                    )}
                  </Paper>
                  
                  <Paper sx={{ p: 3 }}>
                    <Typography variant="h6" gutterBottom>
                      Recent Payments
                    </Typography>
                    
                    {paymentHistory.length > 0 ? (
                      <PaymentHistory 
                        payments={paymentHistory.slice(0, 5)} 
                      />
                    ) : (
                      <Typography>No payment history yet</Typography>
                    )}
                    
                    {paymentHistory.length > 5 && (
                      <Box sx={{ textAlign: 'center', mt: 2 }}>
                        <Button 
                          variant="outlined" 
                          onClick={() => setTabValue(isProvider ? 3 : 2)}
                        >
                          View All Payments
                        </Button>
                      </Box>
                    )}
                  </Paper>
                </Box>
              )}
              
              {/* Bookings Tab */}
              {tabValue === 1 && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    {isProvider ? 'Manage Bookings' : 'My Bookings'}
                  </Typography>
                  
                  <Paper sx={{ p: 3 }}>
                    <Tabs 
                      value={0} 
                      onChange={() => {}}
                      sx={{ mb: 3 }}
                    >
                      <Tab label="All" />
                      <Tab label="Upcoming" />
                      <Tab label="Completed" />
                      <Tab label="Cancelled" />
                    </Tabs>
                    
                    {isProvider ? (
                      providerBookings.length > 0 ? (
                        <BookingList 
                          bookings={providerBookings} 
                          isProvider={true}
                        />
                      ) : (
                        <Typography>No bookings yet</Typography>
                      )
                    ) : (
                      userBookings.length > 0 ? (
                        <BookingList 
                          bookings={userBookings} 
                          isProvider={false}
                        />
                      ) : (
                        <Typography>No bookings yet</Typography>
                      )
                    )}
                  </Paper>
                </Box>
              )}
              
              {/* Reviews Tab (Provider Only) */}
              {isProvider && tabValue === 2 && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    My Reviews
                  </Typography>
                  
                  <Paper sx={{ p: 3 }}>
                    <Typography>Reviews component will be implemented here</Typography>
                  </Paper>
                </Box>
              )}
              
              {/* Payments Tab */}
              {tabValue === (isProvider ? 3 : 2) && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    Payment History
                  </Typography>
                  
                  <Paper sx={{ p: 3 }}>
                    {paymentHistory.length > 0 ? (
                      <PaymentHistory 
                        payments={paymentHistory} 
                      />
                    ) : (
                      <Typography>No payment history yet</Typography>
                    )}
                  </Paper>
                </Box>
              )}
              
              {/* Profile Tab */}
              {tabValue === (isProvider ? 4 : 3) && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    My Profile
                  </Typography>
                  
                  <Paper sx={{ p: 3 }}>
                    <UserProfile user={user} />
                  </Paper>
                </Box>
              )}
              
              {/* Settings Tab */}
              {tabValue === (isProvider ? 5 : 4) && (
                <Box>
                  <Typography variant="h4" gutterBottom>
                    Account Settings
                  </Typography>
                  
                  <Paper sx={{ p: 3 }}>
                    <Typography>Settings component will be implemented here</Typography>
                  </Paper>
                </Box>
              )}
            </>
          )}
        </Grid>
      </Grid>
    </Container>
  );
}
