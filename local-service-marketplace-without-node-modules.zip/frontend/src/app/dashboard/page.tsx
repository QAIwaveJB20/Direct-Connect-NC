import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  TextField,
  InputAdornment,
  Paper,
  Divider,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Tab,
  Tabs,
  Rating,
  Chip,
  Badge,
  Switch,
  FormControlLabel
} from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import LockIcon from '@mui/icons-material/Lock';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PaymentIcon from '@mui/icons-material/Payment';
import SecurityIcon from '@mui/icons-material/Security';
import VerifiedIcon from '@mui/icons-material/Verified';
import BusinessIcon from '@mui/icons-material/Business';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';

const UserDashboardPage = () => {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Box>
      {/* Dashboard Header */}
      <Box sx={{ bgcolor: 'primary.main', color: 'white', py: 4 }}>
        <Container maxWidth="lg">
          <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
            My Dashboard
          </Typography>
          <Typography variant="subtitle1">
            Manage your profile, bookings, and payments
          </Typography>
        </Container>
      </Box>

      {/* Dashboard Content */}
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Grid container spacing={4}>
          {/* Sidebar */}
          <Grid item xs={12} md={3}>
            <Card sx={{ mb: 3 }}>
              <CardContent sx={{ textAlign: 'center' }}>
                <Avatar 
                  sx={{ 
                    width: 100, 
                    height: 100, 
                    mx: 'auto', 
                    mb: 2,
                    bgcolor: 'primary.main'
                  }}
                >
                  JD
                </Avatar>
                <Typography variant="h6" gutterBottom fontWeight="bold">
                  John Doe
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  john.doe@example.com
                </Typography>
                <Badge 
                  overlap="circular"
                  anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                  badgeContent={
                    <VerifiedIcon 
                      color="primary" 
                      sx={{ 
                        fontSize: 20,
                        bgcolor: 'white',
                        borderRadius: '50%'
                      }} 
                    />
                  }
                >
                  <Chip 
                    label="Verified User" 
                    color="primary" 
                    variant="outlined" 
                    size="small"
                  />
                </Badge>
              </CardContent>
            </Card>

            <Card>
              <List component="nav">
                <ListItem button selected={tabValue === 0} onClick={() => setTabValue(0)}>
                  <ListItemIcon>
                    <PersonIcon />
                  </ListItemIcon>
                  <ListItemText primary="My Profile" />
                </ListItem>
                <ListItem button selected={tabValue === 1} onClick={() => setTabValue(1)}>
                  <ListItemIcon>
                    <BusinessIcon />
                  </ListItemIcon>
                  <ListItemText primary="My Bookings" />
                </ListItem>
                <ListItem button selected={tabValue === 2} onClick={() => setTabValue(2)}>
                  <ListItemIcon>
                    <PaymentIcon />
                  </ListItemIcon>
                  <ListItemText primary="Payment Methods" />
                </ListItem>
                <ListItem button selected={tabValue === 3} onClick={() => setTabValue(3)}>
                  <ListItemIcon>
                    <NotificationsIcon />
                  </ListItemIcon>
                  <ListItemText primary="Notifications" />
                </ListItem>
                <ListItem button selected={tabValue === 4} onClick={() => setTabValue(4)}>
                  <ListItemIcon>
                    <SecurityIcon />
                  </ListItemIcon>
                  <ListItemText primary="Security" />
                </ListItem>
                <Divider />
                <ListItem button>
                  <ListItemIcon>
                    <LogoutIcon />
                  </ListItemIcon>
                  <ListItemText primary="Logout" />
                </ListItem>
              </List>
            </Card>
          </Grid>
          
          {/* Main Content */}
          <Grid item xs={12} md={9}>
            <Card>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={tabValue} onChange={handleTabChange} aria-label="dashboard tabs">
                  <Tab label="Profile" id="tab-0" />
                  <Tab label="Bookings" id="tab-1" />
                  <Tab label="Payment Methods" id="tab-2" />
                  <Tab label="Notifications" id="tab-3" />
                  <Tab label="Security" id="tab-4" />
                </Tabs>
              </Box>
              
              {/* Profile Tab */}
              {tabValue === 0 && (
                <CardContent>
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Personal Information
                  </Typography>
                  
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="First Name"
                        defaultValue="John"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Last Name"
                        defaultValue="Doe"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Email Address"
                        defaultValue="john.doe@example.com"
                        variant="outlined"
                        type="email"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Phone Number"
                        defaultValue="(555) 123-4567"
                        variant="outlined"
                      />
                    </Grid>
                  </Grid>
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Address Information
                  </Typography>
                  
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Street Address"
                        defaultValue="123 Main Street"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="City"
                        defaultValue="Charlotte"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        fullWidth
                        label="State"
                        defaultValue="NC"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        fullWidth
                        label="ZIP Code"
                        defaultValue="28202"
                        variant="outlined"
                      />
                    </Grid>
                  </Grid>
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Preferences
                  </Typography>
                  
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={<Switch defaultChecked />}
                        label="Receive email notifications for booking updates"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={<Switch defaultChecked />}
                        label="Receive SMS notifications for booking updates"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={<Switch />}
                        label="Receive promotional emails about new services and offers"
                      />
                    </Grid>
                  </Grid>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <Button variant="contained">
                      Save Changes
                    </Button>
                  </Box>
                </CardContent>
              )}
              
              {/* Bookings Tab */}
              {tabValue === 1 && (
                <CardContent>
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Upcoming Bookings
                  </Typography>
                  
                  <Card variant="outlined" sx={{ mb: 3 }}>
                    <CardContent>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={8}>
                          <Typography variant="subtitle1" fontWeight="bold">
                            Regular Home Cleaning
                          </Typography>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Elite Cleaners
                          </Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                            <Typography variant="body2" sx={{ mr: 3 }}>
                              <strong>Date:</strong> April 22, 2025
                            </Typography>
                            <Typography variant="body2">
                              <strong>Time:</strong> 10:00 AM
                            </Typography>
                          </Box>
                          <Typography variant="body2" paragraph>
                            <strong>Address:</strong> 123 Main Street, Charlotte, NC 28202
                          </Typography>
                          <Chip 
                            label="Confirmed" 
                            color="success" 
                            size="small" 
                            variant="outlined"
                          />
                        </Grid>
                        <Grid item xs={12} sm={4} sx={{ display: 'flex', flexDirection: 'column', alignItems: { xs: 'flex-start', sm: 'flex-end' }, justifyContent: 'space-between' }}>
                          <Typography variant="h6" color="primary.main" fontWeight="bold">
                            $120.00
                          </Typography>
                          <Box>
                            <Button 
                              variant="outlined" 
                              size="small" 
                              sx={{ mr: 1, mb: { xs: 1, sm: 0 } }}
                            >
                              Reschedule
                            </Button>
                            <Button 
                              variant="outlined" 
                              color="error" 
                              size="small"
                            >
                              Cancel
                            </Button>
                          </Box>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold" sx={{ mt: 4 }}>
                    Past Bookings
                  </Typography>
                  
                  {[
                    {
                      service: 'Deep Cleaning',
                      provider: 'Sparkle Home Services',
                      date: 'March 15, 2025',
                      time: '9:00 AM',
                      price: '$220.00',
                      status: 'Completed'
                    },
                    {
                      service: 'Regular Home Cleaning',
                      provider: 'Elite Cleaners',
                      date: 'February 22, 2025',
                      time: '1:00 PM',
                      price: '$120.00',
                      status: 'Completed'
                    },
                    {
                      service: 'Move-Out Cleaning',
                      provider: 'Crystal Clear Cleaning',
                      date: 'January 10, 2025',
                      time: '10:00 AM',
                      price: '$250.00',
                      status: 'Completed'
                    }
                  ].map((booking, index) => (
                    <Card key={index} variant="outlined" sx={{ mb: 2 }}>
                      <CardContent>
                        <Grid container spacing={2}>
                          <Grid item xs={12} sm={8}>
                            <Typography variant="subtitle1" fontWeight="bold">
                              {booking.service}
                            </Typography>
                            <Typography variant="body2" color="text.secondary" gutterBottom>
                              {booking.provider}
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                              <Typography variant="body2" sx={{ mr: 3 }}>
                                <strong>Date:</strong> {booking.date}
                              </Typography>
                              <Typography variant="body2">
                                <strong>Time:</strong> {booking.time}
                              </Typography>
                            </Box>
                            <Chip 
                              label={booking.status} 
                              color="default" 
                              size="small" 
                              variant="outlined"
                            />
                          </Grid>
                          <Grid item xs={12} sm={4} sx={{ display: 'flex', flexDirection: 'column', alignItems: { xs: 'flex-start', sm: 'flex-end' }, justifyContent: 'space-between' }}>
                            <Typography variant="h6" color="text.secondary" fontWeight="bold">
                              {booking.price}
                            </Typography>
                            <Box>
                              <Button 
                                variant="outlined" 
                                size="small" 
                                sx={{ mr: 1 }}
                              >
                                Book Again
                              </Button>
                              <Button 
                                variant="outlined" 
                                size="small"
                              >
                                Review
                              </Button>
                            </Box>
                          </Grid>
                        </Grid>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              )}
              
              {/* Payment Methods Tab */}
              {tabValue === 2 && (
                <CardContent>
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Payment Methods
                  </Typography>
                  
                  <Card variant="outlined" sx={{ mb: 3, p: 2, border: '1px solid', borderColor: 'primary.main' }}>
                    <Grid container spacing={2} alignItems="center">
                      <Grid item>
                        <PaymentIcon fontSize="large" color="primary" />
                      </Grid>
                      <Grid item xs>
                        <Typography variant="subtitle1" fontWeight="bold">
                          Visa ending in 4242
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Expires 12/2026
                        </Typography>
                      </Grid>
                      <Grid item>
                        <Chip label="Default" color="primary" size="small" />
                      </Grid>
                      <Grid item>
                        <Button size="small">Edit</Button>
                      </Grid>
                      <Grid item>
                        <Button size="small" color="error">Remove</Button>
                      </Grid>
                    </Grid>
                  </Card>
                  
                  <Card variant="outlined" sx={{ mb: 3, p: 2 }}>
                    <Grid container spacing={2} alignItems="center">
                      <Grid item>
                        <PaymentIcon fontSize="large" />
                      </Grid>
                      <Grid item xs>
                        <Typography variant="subtitle1" fontWeight="bold">
                          Mastercard ending in 5678
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Expires 08/2025
                        </Typography>
                      </Grid>
                      <Grid item>
                        <Button size="small">Make Default</Button>
                      </Grid>
                      <Grid item>
                        <Button size="small">Edit</Button>
                      </Grid>
                      <Grid item>
                        <Button size="small" color="error">Remove</Button>
                      </Grid>
                    </Grid>
                  </Card>
                  
                  <Button 
                    variant="outlined" 
                    startIcon={<PaymentIcon />}
                    sx={{ mt: 2 }}
                  >
                    Add Payment Method
                  </Button>
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold" sx={{ mt: 4 }}>
                    Billing History
                  </Typography>
                  
                  <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                    <Box sx={{ width: '100%', overflowX: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid rgba(224, 224, 224, 1)' }}>
                            <th style={{ padding: '16px', textAlign: 'left' }}>Date</th>
                            <th style={{ padding: '16px', textAlign: 'left' }}>Description</th>
                            <th style={{ padding: '16px', textAlign: 'left' }}>Payment Method</th>
                            <th style={{ padding: '16px', textAlign: 'right' }}>Amount</th>
                            <th style={{ padding: '16px', textAlign: 'center' }}>Receipt</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { date: 'Apr 15, 2025', description: 'Regular Home Cleaning - Elite Cleaners', method: 'Visa •••• 4242', amount: '$120.00' },
                            { date: 'Mar 15, 2025', description: 'Deep Cleaning - Sparkle Home Services', method: 'Visa •••• 4242', amount: '$220.00' },
                            { date: 'Feb 22, 2025', description: 'Regular Home Cleaning - Elite Cleaners', method: 'Mastercard •••• 5678', amount: '$120.00' },
                            { date: 'Jan 10, 2025', description: 'Move-Out Cleaning - Crystal Clear Cleaning', method: 'Visa •••• 4242', amount: '$250.00' }
                          ].map((transaction, index) => (
                            <tr key={index} style={{ borderBottom: '1px solid rgba(224, 224, 224, 1)' }}>
                              <td style={{ padding: '16px' }}>{transaction.date}</td>
                              <td style={{ padding: '16px' }}>{transaction.description}</td>
                              <td style={{ padding: '16px' }}>{transaction.method}</td>
                              <td style={{ padding: '16px', textAlign: 'right' }}>{transaction.amount}</td>
                              <td style={{ padding: '16px', textAlign: 'center' }}>
                                <Button size="small">Download</Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </Box>
                  </Paper>
                </CardContent>
              )}
              
              {/* Notifications Tab */}
              {tabValue === 3 && (
                <CardContent>
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Notification Settings
                  </Typography>
                  
                  <List>
                    <ListItem>
                      <ListItemText 
                        primary="Email Notifications" 
                        secondary="Receive booking confirmations, reminders, and updates via email"
                      />
                      <Switch defaultChecked />
                    </ListItem>
                    <Divider />
                    <ListItem>
                      <ListItemText 
                        primary="SMS Notifications" 
                        secondary="Receive booking confirmations, reminders, and updates via text message"
                      />
                      <Switch defaultChecked />
                    </ListItem>
                    <Divider />
                    <ListItem>
                      <ListItemText 
                        primary="Push Notifications" 
                        secondary="Receive notifications on your device when you have the app installed"
                      />
                      <Switch />
                    </ListItem>
                    <Divider />
                    <ListItem>
                      <ListItemText 
                        primary="Marketing Communications" 
                        secondary="Receive promotional offers, discounts, and news about new services"
                      />
                      <Switch />
                    </ListItem>
                    <Divider />
                    <ListItem>
                      <ListItemText 
                        primary="Service Provider Updates" 
                        secondary="Receive notifications when your favorite providers add new services"
                      />
                      <Switch defaultChecked />
                    </ListItem>
                  </List>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
                    <Button variant="contained">
                      Save Preferences
                    </Button>
                  </Box>
                </CardContent>
              )}
              
              {/* Security Tab */}
              {tabValue === 4 && (
                <CardContent>
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Password
                  </Typography>
                  
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Current Password"
                        type="password"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="New Password"
                        type="password"
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Confirm New Password"
                        type="password"
                        variant="outlined"
                      />
                    </Grid>
                  </Grid>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 4 }}>
                    <Button variant="contained">
                      Update Password
                    </Button>
                  </Box>
                  
                  <Divider sx={{ my: 3 }} />
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold">
                    Two-Factor Authentication
                  </Typography>
                  
                  <Box sx={{ mb: 3 }}>
                    <FormControlLabel
                      control={<Switch />}
                      label="Enable Two-Factor Authentication"
                    />
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Add an extra layer of security to your account by requiring a verification code in addition to your password when you sign in.
                    </Typography>
                  </Box>
                  
                  <Divider sx={{ my: 3 }} />
                  
                  <Typography variant="h6" gutterBottom fontWeight="bold" color="error">
                    Danger Zone
                  </Typography>
                  
                  <Box sx={{ p: 2, border: '1px solid', borderColor: 'error.light', borderRadius: 1 }}>
                    <Typography variant="subtitle1" gutterBottom fontWeight="bold">
                      Delete Account
                    </Typography>
                    <Typography variant="body2" paragraph>
                      Once you delete your account, there is no going back. Please be certain.
                    </Typography>
                    <Button variant="outlined" color="error">
                      Delete My Account
                    </Button>
                  </Box>
                </CardContent>
              )}
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default UserDashboardPage;
