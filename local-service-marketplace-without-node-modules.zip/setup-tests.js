#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Test script for Local Service Marketplace application
console.log('Running tests for Local Service Marketplace application...');

// Define test directories
const testDir = path.join(__dirname, 'tests');
const backendTestDir = path.join(testDir, 'backend');
const frontendTestDir = path.join(testDir, 'frontend');

// Create test directories if they don't exist
if (!fs.existsSync(testDir)) {
  fs.mkdirSync(testDir);
}
if (!fs.existsSync(backendTestDir)) {
  fs.mkdirSync(backendTestDir);
}
if (!fs.existsSync(frontendTestDir)) {
  fs.mkdirSync(frontendTestDir);
}

// Create backend test files
const authTestFile = path.join(backendTestDir, 'auth.test.js');
const providerTestFile = path.join(backendTestDir, 'provider.test.js');
const bookingTestFile = path.join(backendTestDir, 'booking.test.js');
const paymentTestFile = path.join(backendTestDir, 'payment.test.js');

// Auth test
fs.writeFileSync(authTestFile, `
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const mongoose = require('mongoose');

describe('Authentication API', () => {
  let testUser;
  
  beforeAll(async () => {
    // Clear test users
    await User.deleteMany({ email: { $regex: /^test.*/ } });
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await mongoose.disconnect();
  });

  it('should register a new user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test User',
        email: 'test@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Test St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('token');
    expect(res.body.data).toHaveProperty('name', 'Test User');
    
    testUser = res.body.data;
  });

  it('should login a user', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body.data).toHaveProperty('name', 'Test User');
  });

  it('should not login with incorrect password', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'wrongpassword'
      });
    
    expect(res.statusCode).toEqual(401);
    expect(res.body).toHaveProperty('success', false);
  });

  it('should get current user profile', async () => {
    // First login to get token
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    
    const token = loginRes.body.token;
    
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', \`Bearer \${token}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('name', 'Test User');
    expect(res.body.data).toHaveProperty('email', 'test@example.com');
  });
});
`);

// Provider test
fs.writeFileSync(providerTestFile, `
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const mongoose = require('mongoose');

describe('Provider API', () => {
  let testUser;
  let testToken;
  let testProvider;
  
  beforeAll(async () => {
    // Create test provider user
    const userRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Provider',
        email: 'testprovider@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    testUser = userRes.body.data;
    testToken = userRes.body.token;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await Provider.deleteMany({ user: testUser._id });
    await mongoose.disconnect();
  });

  it('should create a provider profile', async () => {
    const res = await request(app)
      .post('/api/providers')
      .set('Authorization', \`Bearer \${testToken}\`)
      .send({
        businessName: 'Test Business',
        description: 'A test business for testing',
        email: 'business@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body.data).toHaveProperty('businessName', 'Test Business');
    expect(res.body.data).toHaveProperty('user', testUser._id);
    
    testProvider = res.body.data;
  });

  it('should get provider profile', async () => {
    const res = await request(app)
      .get(\`/api/providers/\${testProvider._id}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('businessName', 'Test Business');
  });

  it('should update provider profile', async () => {
    const res = await request(app)
      .put(\`/api/providers/\${testProvider._id}\`)
      .set('Authorization', \`Bearer \${testToken}\`)
      .send({
        businessName: 'Updated Business Name',
        description: 'An updated description'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('businessName', 'Updated Business Name');
    expect(res.body.data).toHaveProperty('description', 'An updated description');
  });

  it('should get top rated providers', async () => {
    const res = await request(app)
      .get('/api/providers/top-rated');
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
  });
});
`);

// Booking test
fs.writeFileSync(bookingTestFile, `
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const Service = require('../../backend/models/Service');
const Booking = require('../../backend/models/Booking');
const mongoose = require('mongoose');

describe('Booking API', () => {
  let customerUser;
  let customerToken;
  let providerUser;
  let providerToken;
  let testProvider;
  let testService;
  let testBooking;
  
  beforeAll(async () => {
    // Create test customer
    const customerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Customer',
        email: 'testcustomer@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    customerUser = customerRes.body.data;
    customerToken = customerRes.body.token;
    
    // Create test provider
    const providerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Provider',
        email: 'testprovider2@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    providerUser = providerRes.body.data;
    providerToken = providerRes.body.token;
    
    // Create provider profile
    const providerProfileRes = await request(app)
      .post('/api/providers')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        businessName: 'Test Business',
        description: 'A test business for testing',
        email: 'business@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    testProvider = providerProfileRes.body.data;
    
    // Create service
    const serviceRes = await request(app)
      .post('/api/services')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        name: 'Test Service',
        description: 'A test service',
        price: 99.99,
        duration: 60,
        category: null,
        provider: testProvider._id
      });
    
    testService = serviceRes.body.data;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^test.*/ } });
    await Provider.deleteMany({ user: providerUser._id });
    await Service.deleteMany({ _id: testService._id });
    await Booking.deleteMany({ service: testService._id });
    await mongoose.disconnect();
  });

  it('should create a booking', async () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const res = await request(app)
      .post('/api/bookings')
      .set('Authorization', \`Bearer \${customerToken}\`)
      .send({
        provider: testProvider._id,
        service: testService._id,
        date: tomorrow.toISOString(),
        startTime: '10:00',
        endTime: '11:00',
        duration: 60,
        price: 99.99,
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        notes: 'Test booking notes'
      });
    
    expect(res.statusCode).toEqual(201);
    expect(res.body.data).toHaveProperty('service', testService._id);
    expect(res.body.data).toHaveProperty('provider', testProvider._id);
    expect(res.body.data).toHaveProperty('user', customerUser._id);
    expect(res.body.data).toHaveProperty('status', 'pending');
    
    testBooking = res.body.data;
  });

  it('should get user bookings', async () => {
    const res = await request(app)
      .get('/api/bookings/user')
      .set('Authorization', \`Bearer \${customerToken}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0]).toHaveProperty('_id', testBooking._id);
  });

  it('should get provider bookings', async () => {
    const res = await request(app)
      .get('/api/bookings/provider')
      .set('Authorization', \`Bearer \${providerToken}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body.data)).toBeTruthy();
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data[0]).toHaveProperty('_id', testBooking._id);
  });

  it('should confirm a booking', async () => {
    const res = await request(app)
      .put(\`/api/bookings/\${testBooking._id}/confirm\`)
      .set('Authorization', \`Bearer \${providerToken}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('status', 'confirmed');
  });

  it('should complete a booking', async () => {
    const res = await request(app)
      .put(\`/api/bookings/\${testBooking._id}/complete\`)
      .set('Authorization', \`Bearer \${providerToken}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body.data).toHaveProperty('status', 'completed');
  });
});
`);

// Payment test
fs.writeFileSync(paymentTestFile, `
const request = require('supertest');
const app = require('../../backend/server');
const User = require('../../backend/models/User');
const Provider = require('../../backend/models/Provider');
const Service = require('../../backend/models/Service');
const Booking = require('../../backend/models/Booking');
const Payment = require('../../backend/models/Payment');
const mongoose = require('mongoose');

describe('Payment API', () => {
  let customerUser;
  let customerToken;
  let providerUser;
  let providerToken;
  let testProvider;
  let testService;
  let testBooking;
  
  beforeAll(async () => {
    // Create test customer
    const customerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Payment Customer',
        email: 'testpaymentcustomer@example.com',
        password: 'password123',
        role: 'user',
        phone: '555-123-4567',
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    customerUser = customerRes.body.data;
    customerToken = customerRes.body.token;
    
    // Create test provider
    const providerRes = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test Payment Provider',
        email: 'testpaymentprovider@example.com',
        password: 'password123',
        role: 'provider',
        phone: '555-987-6543',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        }
      });
    
    providerUser = providerRes.body.data;
    providerToken = providerRes.body.token;
    
    // Create provider profile
    const providerProfileRes = await request(app)
      .post('/api/providers')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        businessName: 'Test Payment Business',
        description: 'A test business for payment testing',
        email: 'paymentbusiness@example.com',
        phone: '555-987-6543',
        website: 'https://testbusiness.com',
        address: {
          street: '456 Provider Ave',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        categories: [],
        availability: {
          monday: { isAvailable: true, start: '09:00', end: '17:00' },
          tuesday: { isAvailable: true, start: '09:00', end: '17:00' },
          wednesday: { isAvailable: true, start: '09:00', end: '17:00' },
          thursday: { isAvailable: true, start: '09:00', end: '17:00' },
          friday: { isAvailable: true, start: '09:00', end: '17:00' },
          saturday: { isAvailable: false, start: '', end: '' },
          sunday: { isAvailable: false, start: '', end: '' }
        },
        serviceArea: 25
      });
    
    testProvider = providerProfileRes.body.data;
    
    // Create service
    const serviceRes = await request(app)
      .post('/api/services')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        name: 'Test Payment Service',
        description: 'A test service for payment',
        price: 99.99,
        duration: 60,
        category: null,
        provider: testProvider._id
      });
    
    testService = serviceRes.body.data;
    
    // Create booking
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const bookingRes = await request(app)
      .post('/api/bookings')
      .set('Authorization', \`Bearer \${customerToken}\`)
      .send({
        provider: testProvider._id,
        service: testService._id,
        date: tomorrow.toISOString(),
        startTime: '10:00',
        endTime: '11:00',
        duration: 60,
        price: 99.99,
        address: {
          street: '123 Customer St',
          city: 'Test City',
          state: 'TS',
          zipCode: '12345',
          country: 'USA'
        },
        notes: 'Test payment booking notes'
      });
    
    testBooking = bookingRes.body.data;
  });

  afterAll(async () => {
    // Clean up
    await User.deleteMany({ email: { $regex: /^testpayment.*/ } });
    await Provider.deleteMany({ user: providerUser._id });
    await Service.deleteMany({ _id: testService._id });
    await Booking.deleteMany({ _id: testBooking._id });
    await Payment.deleteMany({ booking: testBooking._id });
    await mongoose.disconnect();
  });

  it('should create a payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', \`Bearer \${customerToken}\`)
      .send({
        bookingId: testBooking._id,
        paymentType: 'booking'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });

  it('should get payment history', async () => {
    const res = await request(app)
      .get('/api/payments/history')
      .set('Authorization', \`Bearer \${customerToken}\`);
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(Array.isArray(res.body.data)).toBeTruthy();
  });

  it('should create subscription payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        paymentType: 'subscription'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });

  it('should create verification payment intent', async () => {
    const res = await request(app)
      .post('/api/payments/create-payment-intent')
      .set('Authorization', \`Bearer \${providerToken}\`)
      .send({
        paymentType: 'verification'
      });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('clientSecret');
  });
});
`);

// Create frontend test files
const frontendTestFile = path.join(frontendTestDir, 'components.test.js');

fs.writeFileSync(frontendTestFile, `
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { AuthProvider } from '../../frontend/src/app/context/AuthContext';
import { ProviderProvider } from '../../frontend/src/app/context/ProviderContext';
import { ServiceProvider } from '../../frontend/src/app/context/ServiceContext';
import { BookingProvider } from '../../frontend/src/app/context/BookingContext';
import { PaymentProvider } from '../../frontend/src/app/context/PaymentContext';
import LoginPage from '../../frontend/src/app/login/page';
import SignupPage from '../../frontend/src/app/signup/page';
import DashboardPage from '../../frontend/src/app/dashboard/page';
import SearchPage from '../../frontend/src/app/services/search/page';

// Mock the next/navigation
jest.mock('next/navigation', () => ({
  useRouter: () => ({
    push: jest.fn(),
    back: jest.fn(),
    forward: jest.fn()
  }),
  useParams: () => ({
    id: '123'
  })
}));

// Mock the API calls
jest.mock('../../frontend/src/app/api', () => ({
  loginUser: jest.fn().mockResolvedValue({ token: 'test-token', data: { name: 'Test User', email: 'test@example.com' } }),
  registerUser: jest.fn().mockResolvedValue({ token: 'test-token', data: { name: 'New User', email: 'new@example.com' } }),
  getCurrentUser: jest.fn().mockResolvedValue({ data: { name: 'Test User', email: 'test@example.com' } }),
  getProviders: jest.fn().mockResolvedValue({ data: [] }),
  getServices: jest.fn().mockResolvedValue({ data: [] }),
  getUserBookings: jest.fn().mockResolvedValue({ data: [] }),
  getPaymentHistory: jest.fn().mockResolvedValue({ data: [] })
}));

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn()
};
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

describe('Frontend Components', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('Login page renders correctly', () => {
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    expect(screen.getByText('Sign in')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign In/i })).toBeInTheDocument();
  });

  test('Signup page renders correctly', () => {
    render(
      <AuthProvider>
        <SignupPage />
      </AuthProvider>
    );
    
    expect(screen.getByText('Create an Account')).toBeInTheDocument();
    expect(screen.getByText('Account Information')).toBeInTheDocument();
    expect(screen.getByLabelText(/Full Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^Password/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Confirm Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Next/i })).toBeInTheDocument();
  });

  test('Dashboard page shows login prompt when not authenticated', () => {
    render(
      <AuthProvider>
        <BookingProvider>
          <PaymentProvider>
            <DashboardPage />
          </PaymentProvider>
        </BookingProvider>
      </AuthProvider>
    );
    
    expect(screen.getByText('Please log in to view your dashboard')).toBeInTheDocument();
  });

  test('Search page renders correctly', () => {
    render(
      <AuthProvider>
        <ProviderProvider>
          <ServiceProvider>
            <SearchPage />
          </ServiceProvider>
        </ProviderProvider>
      </AuthProvider>
    );
    
    expect(screen.getByText('Find Local Service Providers')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('What service are you looking for?')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Location (City, State, or ZIP)')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Search/i })).toBeInTheDocument();
  });
});
`);

// Create package.json for tests
const testPackageJson = path.join(testDir, 'package.json');

fs.writeFileSync(testPackageJson, `
{
  "name": "local-service-marketplace-tests",
  "version": "1.0.0",
  "description": "Tests for Local Service Marketplace",
  "main": "index.js",
  "scripts": {
    "test:backend": "jest backend",
    "test:frontend": "jest frontend",
    "test": "jest"
  },
  "dependencies": {
    "jest": "^29.5.0",
    "supertest": "^6.3.3",
    "@testing-library/react": "^14.0.0",
    "@testing-library/jest-dom": "^6.0.0"
  },
  "jest": {
    "testEnvironment": "node",
    "testTimeout": 10000
  }
}
`);

console.log('Test files created successfully!');
console.log('To run tests:');
console.log('1. cd tests');
console.log('2. npm install');
console.log('3. npm test');

// Create a test runner script
const testRunnerFile = path.join(__dirname, 'run-tests.js');

fs.writeFileSync(testRunnerFile, `
#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

// Start backend server
console.log('Starting backend server...');
const backend = spawn('node', ['server.js'], {
  cwd: path.join(__dirname, 'backend'),
  env: { ...process.env, NODE_ENV: 'test' },
  stdio: 'inherit'
});

// Wait for backend to start
setTimeout(() => {
  console.log('Running tests...');
  
  // Run tests
  const tests = spawn('npm', ['test'], {
    cwd: path.join(__dirname, 'tests'),
    stdio: 'inherit'
  });
  
  tests.on('close', (code) => {
    console.log(\`Tests completed with code \${code}\`);
    
    // Shutdown backend
    backend.kill();
    process.exit(code);
  });
}, 3000);

// Handle process termination
process.on('SIGINT', () => {
  backend.kill();
  process.exit();
});
`);

// Make test runner executable
try {
  fs.chmodSync(testRunnerFile, '755');
  console.log('Test runner script created and made executable');
} catch (error) {
  console.error('Error making test runner executable:', error);
}

console.log('All test files and scripts have been created successfully!');
